2017-10-27

I hereby agree to the terms of the "Markdown Here Individual Contributor License Agreement", with MD5 checksum 5a845d3ba953b0be7e01fa276c3459e6.

I furthermore declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Adam Pritchard https://github.com/adam-p
