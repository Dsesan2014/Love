2015-12-01

I hereby agree to the terms of the "Markdown Here Individual Contributor Assignment Agreement", with MD5 checksum 20a56153709a38a23316feb565f80756.

I furthermore declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Michael Stepner https://github.com/michaelstepner
