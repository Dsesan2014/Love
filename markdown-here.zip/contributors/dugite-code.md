2018-08-21

I hereby agree to the terms of the "Markdown Here Individual Contributor License Agreement", commit 5bb51a296ed5b0d941ac381420a19ed02886ae21.

I furthermore declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Dugite-Code https://github.com/dugite-code