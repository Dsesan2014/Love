from django.db import models

# Create your models here.

class Book(models.Model):
    nid=models.AutoField(primary_key=True)
    name=models.CharField(max_length=64)
    price=models.DecimalField(max_digits=6,decimal_places=2)
    date=models.DateField()

    publish=models.ForeignKey(to='Publish',to_field='nid',on_delete=models.CASCADE)
    author=models.ManyToManyField(to='Author')


class Publish(models.Model):
    nid=models.AutoField(primary_key=True)
    name=models.CharField(max_length=32)
    addr=models.CharField(max_length=32)
    email=models.EmailField()


class Author(models.Model):
    nid=models.AutoField(primary_key=True)
    name=models.CharField(max_length=64)
    age=models.IntegerField()
    tel=models.CharField(max_length=64)
    birthday=models.DateField()
