from django.shortcuts import render,HttpResponse,redirect
from app01.models import *
# Create your views here.
from PIL import Image,ImageDraw,ImageFont
from io import BytesIO
import random


def code_color():
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

def get_code(request):

    img=Image.new('RGB',(250,40),color=code_color())
    font=ImageFont.truetype('static/MSYH.TTC',35)
    draw=ImageDraw.Draw(img)

    global code_str
    code_str=''
    for i in range(5):
        random_num = str(random.randint(0, 9))
        random_low_alpha = chr(random.randint(97, 122))
        random_upper_alpha = chr(random.randint(65, 90))
        random_char = random.choice([random_num, random_low_alpha, random_upper_alpha])
        code_str += random_char

    draw.text((20+i*10,-5),code_str,code_color(),font)

    request.session['code_str']=code_str
    f=BytesIO()
    img.save(f,'png')
    date=f.getvalue()

    return HttpResponse(date)


def login(request):

    if request.method=='POST':
        name=request.POST.get('name')
        password=request.POST.get('password')
        code=request.POST.get('code_str')

        if code.upper()==code_str.upper():
            if name=='www' and password=='111':
                login_obj=redirect('/book_list/')
                login_obj.set_cookie('is_login',True)
                return login_obj
        else:
            login_obj=redirect('/login/')
            return login_obj

    return render(request,'login.html')



def add_publish(request):
    is_login=request.COOKIES.get('is_login')
    if is_login:

        if request.method=='POST':
            nid=request.POST.get('nid')
            name=request.POST.get('name')
            addr=request.POST.get('addr')
            email=request.POST.get('email')

            Publish.objects.create(nid=nid,name=name,addr=addr,email=email)
            return redirect('/publish_list/')
        return render(request,'add_publish.html')
    return redirect('/login/')


def publish_list(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        publish_lists=Publish.objects.all()
        return render(request,'publish_list.html',{'publish_lists':publish_lists})
    return redirect('/login/')


def delete_publish(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        nid=request.GET.get('nid')
        Publish.objects.filter(nid=nid).delete()
        return redirect('/publish_list/')
    return redirect('/login/')


def edit_publish(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        if request.method=="POST":
            nid=request.POST.get('nid')
            name=request.POST.get('name')
            addr=request.POST.get('addr')
            email=request.POST.get('email')
            Publish.objects.filter(nid=nid).update(nid=nid,name=name,addr=addr,email=email)

            return redirect('/publish_list/')
        nid=request.GET.get('nid')
        Edit_Publish=Publish.objects.filter(nid=nid).first()
        return render(request,'edit_publish.html',{'Edit_Publish':Edit_Publish})

    return redirect('/login/')


def add_book(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:

        if request.method=='POST':
            name=request.POST.get('name')
            price=request.POST.get('price')
            date=request.POST.get('date')
            publish_id=request.POST.get('publish')
            authors=request.POST.getlist('author')
            # print(name,price,date,publish_id)
            book=Book.objects.create(name=name,price=price,date=date,publish_id=publish_id)
            book.author.add(*authors)
            return redirect('/book_list/')

        publish_lists=Publish.objects.all()
        author_lists=Author.objects.all()
        return render(request,'add_book.html',{'publish_lists':publish_lists,'author_lists':author_lists})

    return redirect('/login/')

def book_list(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        book_lists=Book.objects.all()
        publish_lists = Publish.objects.all()
        author_lists = Author.objects.all()
        return render(request,'book_list.html',locals())

    return redirect('/login/')

def delete_book(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        nid=request.GET.get('nid')
        Book.objects.filter(nid=nid).delete()
        return redirect('/book_list/')

    return redirect('/login/')

def edit_book(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        if request.method=="POST":
            nid=request.POST.get('nid')
            name=request.POST.get('name')
            price=request.POST.get('price')
            date=request.POST.get('date')
            Book.objects.filter(nid=nid).update(nid=nid,name=name,price=price,date=date)

            return redirect('/book_list/')

        nid=request.GET.get('nid')
        Edit_Book=Book.objects.filter(nid=nid).first()
        return render(request,'edit_book.html',locals())
    return redirect('/login/')

def add_author(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        if request.method=="POST":
            name=request.POST.get('name')
            age=request.POST.get('age')
            tel=request.POST.get('tel')
            birthday=request.POST.get('birthday')

            Author.objects.create(name=name,age=age,tel=tel,birthday=birthday)
            # return HttpResponse('ok')
            return redirect('/author_list/')
        return render(request,'add_author.html')

    return redirect('/login/')


def author_list(request):

    is_login = request.COOKIES.get('is_login')
    if is_login:
        author_lists=Author.objects.all()
        return render(request,'author_list.html',locals())
    return redirect('/login/')


def delete_author(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        nid=request.GET.get('nid')
        Author.objects.filter(nid=nid).delete()
        return redirect('/author_list/')
    return redirect('/login/')


def edit_author(request):
    is_login = request.COOKIES.get('is_login')
    if is_login:
        if request.method=='POST':
            nid=request.POST.get('nid')
            name=request.POST.get('name')
            age=request.POST.get('age')
            tel=request.POST.get('tel')
            birthday=request.POST.get('birthday')
            Author.objects.filter(nid=nid).update(nid=nid,name=name,age=age,tel=tel,birthday=birthday)

            return redirect('/author_list/')

        nid = request.GET.get('nid')
        Edit_Author=Author.objects.filter(nid=nid).first()
        return render(request,'edit_author.html',locals())

    return redirect('/login/')


from django.contrib.sessions.middleware import SessionsMiddleware