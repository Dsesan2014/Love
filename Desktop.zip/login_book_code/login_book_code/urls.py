"""login_book_code URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app01 import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('add_publish/', views.add_publish),
    path('publish_list/', views.publish_list),
    path('delete_publish/', views.delete_publish),
    path('edit_publish/', views.edit_publish),

    path('add_book/', views.add_book),
    path('book_list/', views.book_list),
    path('delete_book/', views.delete_book),
    path('edit_book/', views.edit_book),

    path('add_author/', views.add_author),
    path('author_list/', views.author_list),
    path('delete_author/', views.delete_author),
    path('edit_author/', views.edit_author),

    path('login/', views.login),
    path('get_code/', views.get_code),
    # path('get_color/', views.get_color),
]
