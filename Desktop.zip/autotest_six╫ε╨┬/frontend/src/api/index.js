import * as api from './';

export default api;
