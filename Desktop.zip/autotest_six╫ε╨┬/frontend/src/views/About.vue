<template>
  <section>
    </br>
    </br>
    </br>
    <div style="font-size:20px;">
      &nbsp;&nbsp;&nbsp;&nbsp;1989 年圣诞，Guido van Rossum 为了打发无聊的圣诞假期，决定找点事来做。他选择实现一门编程语言。这门编程语言就是 Python。
    </div>
    <div style="font-size:20px;">
      &nbsp;&nbsp;&nbsp;&nbsp;2000年10月16日，Python 2.0 发布。
    </div>
    <div style="font-size:20px;">
      &nbsp;&nbsp;&nbsp;&nbsp;2008年12月3日，Python 3.0 发布。
    </div>
    <div style="font-size:20px;">
      &nbsp;&nbsp;&nbsp;&nbsp;从创立之初到现在，在整整三十年的时间里，Python一步步的成长到现在，被广泛的应用于服务开发，运维，科学计算，理论模拟等计算机领域中。越来越多的人爱上 Python，并用自己的形式回馈 Python 社区。可能 Guido 他自己都没想到，当时的一时兴起所创造的语言，会在这么多的领域得到应用。某种意义上来讲，他所创造的这门语言，在一定程度上改变了计算机世界。。
    </div>
    </br>
    <div style="font-size:20px;">
      &nbsp;&nbsp;&nbsp;&nbsp;在传统的企业思维概念中，测试和监控很多时候是完全不同的概念，测试有测试部门，运维有运维部门，大家彼此分工明确，互不耦合。但随着项目功能和业务逻辑的日益复杂，随着用户行为和体验要求逐渐提高，慢慢的该模式瓶颈也逐渐出现。于是近些年为了提高开发、测试、运维整体的效率，避免敏捷开发使用中的频繁开发、部署、上线测试带来的问题，DevOps开发概念应运而生。
    </div>
    </br>
    <div style="font-size:20px;">
      &nbsp;&nbsp;&nbsp;&nbsp;在该autocensor项目中，结合devops理念，我们将普通的测试、监控、预警模块集成到了一起，根据配置文件打通一条完整的运维链，大大简化企业项目测试监控实现流程，希望能够对关注的朋友们产生一些帮助，谢谢~
    </div>
  </section>
</template>
