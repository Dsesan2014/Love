// 获取接口用例页面分页排序等信息
export const getApiCasePageInfo = state => {
    return state.apiCasePageInfo
};
// 获取用例列表页面分页排序等信息
export const getApiCaseSuitePageInfo = state => {
    return state.apiCaseSuitePageInfo
};
