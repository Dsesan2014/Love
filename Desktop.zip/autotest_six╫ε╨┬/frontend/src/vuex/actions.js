// 接口用例页面分页排序等信息
export const setApiCasePageInfo = ({commit}) => {
    commit('setApiCasePageInfo')
}
// 用例列表页面分页排序等信息
export const setApiCaseSuitePageInfo = ({commit}) => {
    commit('setApiCaseSuitePageInfo')
}
