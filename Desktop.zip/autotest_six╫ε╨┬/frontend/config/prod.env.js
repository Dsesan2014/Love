'use strict'
module.exports = {
  NODE_ENV: '"production"',
  CASE_IMPORT_URI: '"/api/importTestCases"'
}
