#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Flask, jsonify, request, abort
from bson import ObjectId
import datetime
from flask_login import login_required

from app import app
from models.host import Host
from utils import common
from utils.common_tool import record_spent_time
from controllers.validate_request import validate_sip


MODULE_NAME = "Host"

# host信息
@app.route('/api/project/<project_id>/hostList', methods=['GET', 'POST'])
@login_required
@record_spent_time(MODULE_NAME)
@validate_sip
def host_list(project_id):
    total_num, host_info = common.get_total_num_and_arranged_data(Host, request.args)
    return jsonify({'status': 'ok', 'data': {'totalNum': total_num, 'rows': host_info}})


@app.route('/api/project/<project_id>/addHost', methods=['POST'])
@login_required
@record_spent_time(MODULE_NAME)
@validate_sip
def add_host(project_id):
    try:
        request_data = request.get_json()
        request_data["status"] = True
        request_data["projectId"] = ObjectId(project_id)
        request_data["createAt"] = datetime.datetime.utcnow()
        request_data["lastUpdateTime"] = datetime.datetime.utcnow()
        filtered_data = Host.filter_field(request_data, use_set_default=True)
        Host.insert(filtered_data)
        return jsonify({'status': 'ok', 'data': '新建成功'})
    except BaseException as e:
        return jsonify({'status': 'failed', 'data': '新建失败 %s' % e})


@app.route('/api/project/<project_id>/hostList/<hostId>/updateHost', methods=['POST'])
@login_required
@record_spent_time(MODULE_NAME)
@validate_sip
def update_host(project_id, host_id):
    """
    更改和删除除都走该处接口，删除时只是将指定记录的isDeleted字段置为True
    :param project_id:
    :param host_id:
    :return:
    """
    try:
        filtered_data = Host.filter_field(request.get_json())
        for key, value in filtered_data.items():
            Host.update({"_id": ObjectId(host_id)},
                        {'$set': {key: value}})
        update_response = Host.update({"_id": ObjectId(host_id)},
                                      {'$set': {'lastUpdateTime': datetime.datetime.utcnow()}})
        if update_response["n"] == 0:
            return jsonify({'status': 'failed', 'data': '未找到相应更新数据！'})
        return jsonify({'status': 'ok', 'data': '更新成功'})
    except BaseException as e:
        return jsonify({'status': 'failed', 'data': '更新失败: %s' % e})

