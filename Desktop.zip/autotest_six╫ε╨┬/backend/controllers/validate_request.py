#!/usr/bin/env python3
# coding=utf-8
"""
author = jamon
"""

from functools import wraps
from flask import jsonify, request, redirect, abort
import time

from config import censor_config
from utils.common_tool import is_ip_in_range, cal_sign
from utils.ob_log import logger
from models.user_nonce import UserNonce
from models.user_token import UserToken


MAX_TIME_LATER = 60  # 请求最大延迟60s


def validate_sip(func):
    """
    验证sip是否在白名单内
    :param func:
    :return:
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        sip = request.remote_addr
        if sip not in censor_config.white_ips_special and not is_ip_in_range(sip, censor_config.white_ips_range):
            logger.warn("{0} ip{1} error!".format(func.__name__, sip))
            return jsonify({'status': 'failed', 'data': 'ip不在白名单内 %s' % sip})
        return func(*args, **kwargs)

    return wrapper


def validate_sign(func):
    """
    签名验证，防重放攻击
    :param user_id: int, 用户id
    :param stime: 时间戳， int
    :param nonce: int, 随机数
    :param sign: 签名串
    :return:
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        data = request.get_json()
        user_id = data.get("user_id", 0)
        stime = data.get("stime", 0)
        nonce = data.get("nonce", 0)
        sign = data.get("sign", "")
        if MAX_TIME_LATER < time.time() - stime or UserNonce().is_exist(user_id, nonce)\
                or sign != cal_sign(UserToken.get_instance().get_token_by_userid(user_id), stime, nonce):
            logger.warn("receive a invalid request: {}".format([stime, nonce, sign]))
            return jsonify({'status': 'failed', 'data': '无效请求！'})

        # 验证通过时需要将nonce添加到缓存中
        UserNonce().insert(user_id, nonce)
        return func(*args, **kwargs)
    return wrapper


def validate_ip_sign(func):
    """
       请求验证，包括ip白名单，和防重放攻击
       :param sip: ip白名单
       :param user_id: int, 用户id
       :param stime: 时间戳， int
       :param nonce: int, 随机数
       :param sign: 签名串
       :return:
       """
    @wraps(func)
    def wrapper(*args, **kwargs):
        sip = request.remote_addr
        data = request.get_json()
        user_id = data.get("user_id", 0)
        stime = data.get("stime", 0)
        nonce = data.get("nonce", 0)
        sign = data.get("sign", "")
        if MAX_TIME_LATER < time.time() - stime or UserNonce().is_exist(user_id, nonce) \
                or sign != cal_sign(UserToken.get_instance().get_token_by_userid(user_id), stime, nonce):
            logger.warn("receive a invalid request: {}".format([stime, nonce, sign]))
            return jsonify({'status': 'failed', 'data': '无效请求！'})

        if sip not in censor_config.white_ips_special and not is_ip_in_range(sip, censor_config.white_ips_range):
            logger.warn("{0} ip{1} error!".format(func.__name__, sip))
            return jsonify({'status': 'failed', 'data': 'ip不在白名单内 %s' % sip})

        # 验证通过时需要将nonce添加到缓存中
        UserNonce().insert(user_id, nonce)
        return func(*args, **kwargs)

    return wrapper

