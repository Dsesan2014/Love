# coding:utf-8

'''
author: jamon
'''

import hashlib
import os
import re
import sys
import traceback
import time
import ujson
import uuid
from functools import wraps
import socket, fcntl, struct

from utils.ob_log import logger

MAX_EXCEED_TIME = 2


def get_md5(content):
    c_md5 = hashlib.md5()
    c_md5.update(content.encode("utf-8"))
    return c_md5.hexdigest()


def get_rand_16():
    return get_md5_16(uuid.uuid1().hex)


def get_md5_16(content):
    return get_md5(content)[8:-8]


def record_spent_time(module_name):
    """
    每个handler请求时间的装饰器
    :param filename:
    :return:
    """

    def record_spent(func):
        @wraps(func)
        def handler_func(*args, **kwargs):
            start_time = time.time()
            logger.info("{}:{} start at: {}".format(module_name, func.__name__, start_time))

            res = func(*args, **kwargs)

            end_time = time.time()
            logger.info("{}:{} end at: {}".format(module_name, func.__name__, end_time))

            spent_time = end_time - start_time
            if spent_time > MAX_EXCEED_TIME:
                logger.error("{}:{} took {}s, time out !!!".format(module_name, func.__name__, spent_time))
            else:
                logger.info("{}:{} took {}s".format(module_name, func.__name__, spent_time))
            return res

        return handler_func

    return record_spent


def is_ip(ipstr):
    p = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
    if p.match(ipstr):
        return True
    else:
        return False


def is_ip_in_range(ip, range_list=[]):
    """
    判断ip是否在指定区间的ip段内
    :param ip:
    :param range_list: [[start_ip, end_ip], [], ...]
    :return:
    """
    ip2int = lambda x: sum([256 ** j * int(i) for j, i in enumerate(x.split('.')[::-1])])
    compare_ip = ip2int(ip)
    for r in range_list:
        start_ip = ip2int(r[0])
        end_ip = ip2int(r[1])
        if compare_ip>=start_ip and compare_ip<=end_ip:
            return 1

    return 0


def try_create_dir(dir_path):
    """
    尝试创建目录
    :param dir_path:
    :return:
    """
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        try:
            os.makedirs(dir_path)
        except Exception:
            logger.error('try_create_dir create {0},err {1}'.format(dir_path, traceback.format_exc()))


def get_mac_address():
    mac=uuid.UUID(int = uuid.getnode()).hex[-12:]
    return ":".join([mac[e:e+2] for e in range(0,11,2)])


def get_local_ip(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    inet = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
    ret = socket.inet_ntoa(inet[20:24])
    return ret


def gen_nonce():
    return get_rand_16()


def cal_sign(token, stime, nonce):
    """
    计算签名
    :return:
    """
    return get_md5("{0}, {1}, {2}123456".format(token, stime, nonce))

