# coding=utf-8
"""
author = jamon
"""

import time

from utils.sendReportEmail import send_report_email


def get_file_lines_num(file_name):
    count = 0
    thefile = open(file_name, 'r')
    while True:
        buffer = thefile.read(1024 * 8192)
        if not buffer:
            break
        count += buffer.count('\n')
    thefile.close()
    return count


def get_file_last_lines(file_name, start_line_pos, nums=10):
    """
    获取文件指定位置开始后的行数
    :param file_name: str, 文件名绝对路径
    :param start_line_pos: int, 从第几行开始取
    :param nums: int, 需要返回的文件行数
    :return: []
    """
    result = []
    with open(file_name, "r") as f:
        index = 0
        while True:
            temp = f.readline()
            if not temp or 0>=nums:
                break
            index += 1
            if index >= start_line_pos:
                result.append(temp)
                nums -= 1
    return result


class MonitorFile(object):
    """日志文件监控"""

    def __init__(self):
        self.file_info = {}   # {filepath: {"num": int(line num), "time": the time of count}, filepath2: ...}

    def add_files(self, file_list=[]):
        for f in file_list:
            if f not in self.file_info.keys():
                self.file_info[f] = {"num": 0, "time": 0}

    def _get_last_num(self, file_path):
        if file_path not in self.file_info.keys():
            return 0
        return self.file_info[file_path]["num"]

    def _update_file_info(self, file_path, new_num):
        if file_path not in self.file_info.keys():
            self.file_info[file_path] = {"num": new_num, "time": int(time.time())}

    def _monitor_file(self, file_path):
        """
        实际监控具体文件
        :param file_path: 文件路径
        :return:
        """
        cur_num = get_file_lines_num(file_path)
        last_num = self._get_last_num(file_path)
        print("hhhhhhh:", file_path, cur_num, last_num)
        if cur_num > last_num:
            # 文件行数发生变化
            self._update_file_info(file_path, cur_num)
            result = get_file_last_lines(file_path, last_num)

            # 触发预警， 此处简单化使用邮件，后续可以改成调用预警通知的微服务
            send_report_email("hehuilin@oldboylinux.com", "8JSEtcjKqd8j4SvZ", mail_namelist=["352622654@qq.com"]
                              , title="test", content='\n'.join(result))

    def check(self):
        for f in self.file_info.keys():
            self._monitor_file(f)
