# coding=utf-8
#! /usr/bin/env python3
import os
import time
from threading import Thread
from app import app
from utils.ob_log import logger
from utils.monitor import MonitorFile


def monitor_dir(dir_path, suffix=""):
    """
    监控指定目录下的所有文件
    :param dir_path: 目录路径
    :param suffix: 需要监控的文件后缀名，空值代表监控所有文件
    :return:
    """
    monitor = MonitorFile()
    while 1:
        monitor_files = []
        for root, dirs, files in os.walk(dir_path):
            for fn in files:
                if fn.endswith(suffix):
                    monitor_files.append(os.path.join(root, fn))

        monitor.add_files(monitor_files)
        monitor.check()
        time.sleep(5)


if __name__ == '__main__':
    log_dir = "./logs/"
    module_name = "backend"
    log_level = "debug"
    logger.init(module_name=module_name, log_dir=log_dir, level=log_level)
    file_monitor = Thread(target=monitor_dir, args=("./logs", ".log"))
    file_monitor.start()

    app.run(debug=True, host='0.0.0.0', port=5050)
