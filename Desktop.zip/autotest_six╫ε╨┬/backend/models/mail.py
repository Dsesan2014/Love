# coding=utf-8
"""
author = jamon
"""


from utils.mongo import *


# 类名定义 collection
class Mail(Model):

    class Meta:
        database = db
        collection = 'mail'

    # 字段
    name = StringField()      # 名称
    isDeleted = BooleanField(field_name='isDeleted', default=False)      # 是否已被删除
    _id = ObjectIdField()
    projectId = ObjectIdField()                       # 项目ID
    mailAddress = StringField()                       # 邮件地址
    description = StringField()                       # 描述信息
    status = BooleanField(field_name='status', default=False)  # 状态
    createAt = DateField()
    creatorNickName = StringField()
    lastUpdateTime = DateField()
    lastUpdatorNickName = StringField()


if __name__ == '__main__':
    pass
