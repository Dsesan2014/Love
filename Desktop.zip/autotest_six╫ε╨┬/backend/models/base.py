# coding=utf-8
"""
author = jamon
"""

from pymongo import MongoClient

from config import censor_config


class DbConn(object):

    def __init__(self):
        mongo_uri = "mongodb://{user}:{passwd}@{host}:{port}/{database}".format(
            user=censor_config._AUTOTEST_PLATFORM_MONGO_USERNAME,
            passwd=censor_config._AUTOTEST_PLATFORM_MONGO_PASSWORD,
            host=censor_config._AUTOTEST_PLATFORM_MONGO_HOST,
            port=censor_config._AUTOTEST_PLATFORM_MONGO_PORT,
            database="admin",
            )
        self.mongo_conn = MongoClient(mongo_uri)


db_conn = DbConn()