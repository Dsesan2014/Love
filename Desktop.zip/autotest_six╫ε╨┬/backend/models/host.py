# coding=utf-8
"""
author = jamon
"""

from utils.mongo import *


class Host(Model):

    class Meta:
        database = db
        collection = 'host'

    # 字段
    name = StringField()        # 主机名
    isDeleted = BooleanField(field_name='isDeleted', default=False)  # 该记录是否已被删除
    _id = ObjectIdField()
    projectId = ObjectIdField()          # 项目id
    host = StringField()                 # 主机地址
    description = StringField()          # 描述详情
    status = BooleanField(field_name='status', default=False)    # 状态
    createAt = DateField()
    creatorNickName = StringField()
    lastUpdateTime = DateField()
    lastUpdatorNickName = StringField()
