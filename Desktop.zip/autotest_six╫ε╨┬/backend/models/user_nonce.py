# coding=utf-8
"""
author = jamon
"""

from utils.singleton import Singleton


class UserNonce(object, metaclass=Singleton):
    """
     用户nonce临时存储，用于防重放攻击
    """

    def __init__(self):
        self.nonce = {}     # {user1: [nonce1, nonce2, ...], user2:...}

    def is_exist(self, user_id, nonce):
        if user_id in self.nonce.keys() and nonce in self.nonce[user_id]:
            return 1

        return 0

    def insert(self, user_id, nonce):
        if self.is_exist(user_id, nonce):
           return 0

        if user_id in self.nonce.keys():
            self.nonce[user_id].append(nonce)
        else:
            self.nonce[user_id] = [nonce]



