# coding=utf-8
"""
author = jamon
"""
from models.base import db_conn
from utils.common_tool import get_rand_16


class UserToken(object):
    """
    每次登录成功后给用户一个token

    数据设计结构:
    user_id int(32) not null,
    token char(24) NOT NULL DEFAULT '',

    CONSTRAINT th_pk PRIMARY KEY (id)
    """
    _instance = None
    _database_name = "ob_test"
    _table_name = "user_token"

    @classmethod
    def get_instance(cls):
        if not cls._instance:
            cls._instance = UserToken()
        return cls._instance

    def __init__(self):
        self.conn = db_conn.mongo_conn[UserToken._database_name][UserToken._table_name]

    def gen_token(self):
        return get_rand_16()

    def get_token_by_userid(self, user_id):
        return self.conn.find({"user_id": user_id})

    def upsert_token(self, user_id, token):
        self.conn.update_one({"user_id":user_id}, {"$set": {"token": token}}, upsert=True)
        return 1



