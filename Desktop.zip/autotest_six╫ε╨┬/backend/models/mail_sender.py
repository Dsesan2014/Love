# coding=utf-8
"""
author = jamon
"""

from utils.mongo import *


# 类名定义 collection
class MailSender(Model):

    class Meta:
        database = db
        collection = 'mailSender'

    # 字段
    username = StringField()        # 用户名
    password = StringField()        # 密码
    _id = ObjectIdField()
    projectId = ObjectIdField()     # 项目id
    createAt = DateField()
    status = BooleanField(field_name='status', default=True)    # 状态
    creatorNickName = StringField()
    lastUpdateTime = DateField()
    lastUpdatorNickName = StringField()


if __name__ == '__main__':
    pass