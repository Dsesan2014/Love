#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import socket
import struct
import time

import requests
from lxml import etree
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By

from test import get_root_dir
from share.parse_json import ParseJson
from share.ob_log import logger

info = ParseJson.loads(get_root_dir() + "/config.json")  # 讀取配置信息
URI = info.get("uri")  # 域名
USER = info.get("user")  # 測試賬號


def get_cookies():
    """
    获取用户登录cookie
    :return: cookie
    """
    username = USER['user']
    password = USER['password']
    url = URI + '/#/login'
    dr = webdriver.PhantomJS()
    dr.get(url)
    input_username = WebDriverWait(dr, 10).until(
        ec.presence_of_element_located((By.CSS_SELECTOR, '#app > div > div > label:nth-child(2) > input[type="text"]'))
    )
    input_username.send_keys(username)
    input_password = WebDriverWait(dr, 5).until(
        ec.presence_of_element_located((By.CSS_SELECTOR, '#app > div > div > label.psd > input[type="password"]'))
    )
    input_password.send_keys(password)
    dr.find_element_by_css_selector('#app > div > div > button').click()
    time.sleep(10)
    cookies0 = dr.get_cookies()
    _cookies = {}
    for a in cookies0:
        name = a["name"]
        value = a["value"]
        _cookies[name] = value
    return _cookies


# cookies = get_cookies()


def request_get(api, payload=None):
    global cookies
    url = URI + api
    try:
        s1 = time.time()
        response = requests.request("GET", url, cookies=cookies, params=payload, timeout=20)
        if response.status_code == 401:
            cookies = get_cookies()
            response = requests.request("GET", url, cookies=cookies, params=payload, timeout=20)
        s2 = time.time()
        logger.debug("request_get {} took {}s, params={}".format(api, s2-s1, payload))
        return response
    except requests.exceptions.ReadTimeout:
        logger.error(ErrMsg.normal_err(api, payload, errmsg='请求超时-20s'))
        raise


def request_post(url, payload=None):
    # global cookies
    try:
        # headers = {
        #     'Content-Type': "application/json",
        # }
        s1 = time.time()
        response = requests.post(url, json.dumps(payload), timeout=3)
        # response = requests.request("GET", url, cookies=cookies, params=payload, timeout=20)
        s2 = time.time()
        logger.debug("request_post {} took {}s, params={}".format(url, s2 - s1, payload))
        return response
    except requests.exceptions.ReadTimeout:
        logger.error(ErrMsg.normal_err(url, payload, errmsg='请求超时-20s'))
        raise


def check_err(_file):
    """
    检查测试用例是否有不通过的情况
    :param _file: str, html路径
    :return: bool,
    """
    dr = webdriver.PhantomJS()
    dr.maximize_window()
    dr.get(_file)
    selector = etree.HTML(dr.page_source)
    obj = selector.xpath(r'/html/body/p/a[2]/text()')
    num = int(obj[0][4])
    dr.close()
    if num > 0:
        return True
    else:
        return False


class IpTransfer(object):
    """
    IP互转方法
    """

    @classmethod
    def int2ip(cls, num):
        """

        :param num:
        :return:
        """
        # int to ip address
        return socket.inet_ntoa(struct.pack('I', socket.htonl(num)))

    @classmethod
    def ip2int(cls, ip):  # ip address to int
        return socket.ntohl(struct.unpack("I", socket.inet_aton(str(ip)))[0])


class ErrMsg(object):
    """
    格式化错误信息
    """
    @classmethod
    def normal_err(cls, api, payload=None, errmsg=None, response=None):
        # _msg = """errmsg:{0}, request_url:{1}, request_data:{2}, response_data:{3}""" \
        #     .format(errmsg, uri+api, payload, response)
        _msg = {"user": USER, "errmsg": errmsg, "request_url": URI + api, "request_data": payload,
                "response_data": response}
        return _msg
