#!/usr/bin/env python
# -*- coding: utf-8 -*-


import unittest

from test.test_case.base_func import request_post, ErrMsg
from test.lib.obTestCase import ObTestCase

from share.ob_log import logger

BASE_URL = "http://oldboy.iespoir.com:8889"
MJ_LOGIN_API = '/majapi/login'


class MjLoginTest(ObTestCase):
    def test_login(self):
        url = BASE_URL + MJ_LOGIN_API
        param1 = {"user": "oldboy1", "password": "123456"}
        r = request_post( url, payload=param1)
        print("afafalfka:", r.text)

        self.assertEqual(200, r.status_code, ErrMsg.normal_err(url, errmsg='code!=200'))
        self.assertEqual(0, r.json()['ret'],
                         ErrMsg.normal_err(url, errmsg='请求错误', response=r.json())
                         )

        param2 = {"user": 100, "password": "123456"}   # 不存在该账户
        r = request_post(url, payload=param2)
        self.assertEqual(200, r.status_code, ErrMsg.normal_err(url, errmsg='code!=200'))
        self.assertTrue(r.json()['ret'] != 0,
                        ErrMsg.normal_err(url, errmsg='请求错误', response=r.json())
                        )

        logger.critical("hhhhhhhhhhellllllllllo")


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(all)
    unittest.TextTestRunner(verbosity=2).run(suite)
