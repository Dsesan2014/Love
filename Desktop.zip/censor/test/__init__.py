# coding=utf-8
"""
author = jamon
"""

import sys


def get_root_dir():
    """
    获取项目根目录
    :return:
    """
    return sys._getframe().f_code.co_filename.rsplit('/', 2)[0]