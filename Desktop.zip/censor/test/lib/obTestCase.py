# coding=utf-8
"""
author = jamon
"""

import unittest
from share.ob_log import logger


class ObTestCase(unittest.TestCase):
    """
    ObTestCase类中的断言方法进行二次封装，加入logger
    """

    def assertEqual(self, first, second, msg=None):
        try:
            super(ObTestCase, self).assertEqual(first, second, msg=None)
        except Exception:
            logger.critical('{}'.format(msg))
            raise

    def assertIn(self, member, container, msg=None):
        try:
            super(ObTestCase, self).assertIn(member, container, msg=None)
        except Exception:
            logger.error('{}'.format(msg))
            raise

    def assertNotEqual(self, first, second, msg=None):
        try:
            super(ObTestCase, self).assertNotEqual(first, second, msg=None)
        except Exception:
            logger.error('{}'.format(msg))
            raise

    def assertListEqual(self, list1, list2, msg=None):
        try:
            super(ObTestCase, self).assertListEqual(list1, list2, msg=None)
        except Exception:
            logger.error('{}'.format(msg))
            raise

    def assertNotIn(self, member, container, msg=None):
        try:
            super(ObTestCase, self).assertNotIn(member, container, msg=None)
        except Exception:
            logger.error('{}'.format(msg))
            raise

    def assertTrue(self, expr, msg=None):
        try:
            super(ObTestCase, self).assertTrue(expr, msg=None)
        except Exception:
            logger.error('{}'.format(msg))
            raise

    def assertFalse(self, expr, msg=None):
        try:
            super(ObTestCase, self).assertFalse(expr, msg=None)
        except Exception:
            logger.error('{}'.format(msg))
            raise