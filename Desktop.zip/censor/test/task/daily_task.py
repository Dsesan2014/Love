#!/usr/bin/env python
# -*- coding: utf-8 -*-

import asyncio
import os
import sys
import time
import datetime
import unittest

from selenium import webdriver

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.utils import formatdate

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from test.lib import HTMLTestRunner_PY3

from test import get_root_dir
from share.parse_json import ParseJson

info = ParseJson.loads(get_root_dir() + "/config.json")
CASE_DIR = get_root_dir() + info.get('case_dir')
REPORT_DIR = get_root_dir() + info.get('report_dir')
MODULE_NAME = info.get("service_name", '')
TIME = info["daily_run"].get("time").split(',')
MAIL_TO = info["daily_run"].get("mail_to").split(',')
MAIL_SERVER = info["daily_run"].get("mail_server")
MAIL_USER = info["daily_run"].get("mail_user")
MAIL_PASSWORD = info["daily_run"].get("mail_password")


def timer_runner(run_time):
    """
    定时器,用于每天定时执行测试脚本
    :param run_time: list, ['09:00','14:00']
    :return: decorator
    """

    def decorator(func):
        def wrapper(*args, **kw):
            while True:
                d = datetime.datetime.now()
                now = time.strftime("%H:%M", time.localtime(time.time()))

                if now in run_time:
                    func(*args, **kw)
                else:
                    # print(d)
                    time.sleep(20)

        return wrapper

    return decorator


def get_result_pic(_file):
    """
    :param _file: str,html地址
    :return: png,返回html截图
    """
    pic_name = REPORT_DIR + '/result—html.png'
    dr = webdriver.PhantomJS()
    dr.maximize_window()
    dr.get(_file)
    time.sleep(3)
    dr.get_screenshot_as_file(pic_name)
    dr.close()
    return pic_name


def send_mail(server, fro, to, subject, _file):
    """
    发送图片&带附件邮件
    :param server: {},server['name'],server['port'], server['user'], server['pass_wd']
    :param fro: str, 'jamon@oldboy.com'
    :param to: list, ['jamon@oldboy.com']
    :param subject: str,'——每日接口监控'
    :param _file: str,'_file_path'
    :return: None
    """
    msg = MIMEMultipart()
    msg['From'] = fro
    msg['Subject'] = subject
    msg['To'] = ",".join(to)
    msg['Date'] = formatdate(localtime=True)

    # 构造图片
    html_pic = get_result_pic(_file)
    fp = open(html_pic, 'rb')
    msg_image = MIMEImage(fp.read())
    fp.close()
    msg_image.add_header('Content-ID', '<html_image>')
    msg.attach(msg_image)

    # html格式构造, 图片在html中展示
    html = """\
    <html> 
      <body> 
           <br><img src="cid:html_image"></br>
      </body> 
    </html> 
    """
    htm = MIMEText(html, 'html', 'utf-8')
    msg.attach(htm)

    # 添加附件 测试报告的html文件
    att = MIMEText(open(_file, 'rb').read(), 'base64', 'gb2312')
    att["Content-Type"] = 'application/octet-stream'
    att.add_header("Content-Disposition", "attachment", filename=os.path.basename(_file))
    msg.attach(att)

    smt = smtplib.SMTP_SSL()
    smt.connect(server['name'])
    smt.login(server['user'], server['pass_wd'])
    smt.sendmail(fro, to, msg.as_string())
    smt.close()
    print('mail send success')


def new_report(test_report):
    """
    获取最新的测试报告文件
    :param test_report: str, 测试报告文件夹所在路径
    :return: file_new, str, 最新的测试报告邮件file——path
    """
    lists = os.listdir(test_report)
    lists.sort(key=lambda fn: os.path.getmtime(test_report + "/" + fn))  # 按时间排序
    file_new = os.path.join(test_report, lists[-1])
    print('release_report done :{}'.format(file_new))
    return file_new


def run(project):
    """
    读取执行测试用例,生成测试报告
    :param project: str,'test'
    :return:
    """
    test_dir = CASE_DIR  # "测试用例存放目录"
    test_report = REPORT_DIR  # "测试报告存放目录"
    print('<<===== Begin load test case =====>>')
    discover = unittest.defaultTestLoader.discover(test_dir, pattern='test_*.py')
    now = time.strftime("%Y-%m-%d_%H-%M-%S")
    _filename = test_report + '/' + now + 'result.html'

    fp = open(_filename, 'wb')
    runner = HTMLTestRunner_PY3.HTMLTestRunner(
        stream=fp,
        title='{}测试报告'.format(project),
        description='测试用例执行情况:',
    )
    print('<<===== Begin run test_case =====>>')
    runner.run(discover)
    fp.close()
    print('<<===== Done =====>>')

    release_report = new_report(test_report)
    return release_report


@timer_runner(TIME)
def daily_task():
    project = MODULE_NAME
    server = {
        'name': MAIL_SERVER,
        'user': MAIL_USER,
        'pass_wd': MAIL_PASSWORD
    }
    fro = MAIL_USER
    to = MAIL_TO
    subject = '{}每日接口测试报告'.format(project)
    release_report = run(project)
    send_mail(server, fro, to, subject, release_report)
    time.sleep(5)


if __name__ == '__main__':
    daily_task()
