#!/usr/bin/env python
# -*- coding: utf-8 -*-

import asyncio
import time
import json

import requests
import traceback

from test import get_root_dir
from share.parse_json import ParseJson
from share.ob_log import logger
from share.time_convert import get_cur_strtime

info = ParseJson.loads(get_root_dir() + "/config.json")
LOG_DIR = info.get("log_dir", "./")
MODULE_NAME = info.get("service_name", '')
DIN_ROBOT = info.get("dindin")
PHONE_NUMBERS = info.get("phone_numbers", "17620347882")
SMS_URL = info.get("sms_url")


def md5(data):
    """
    mds加密,接受str 和　dict
    :param data: str or dict
    :return:　md5值
    """
    import hashlib
    m = hashlib.md5()
    if isinstance(data, str):
        m.update(data.encode('utf8'))
        return m.hexdigest()
    if isinstance(data, dict):
        m.update(json.dumps(data, sort_keys=True).encode('utf8'))
        return m.hexdigest()


def call_din(msg):
    """
    din_talk,调用钉钉机器人发消息
    :param msg:text
    :return:
    """
    url = DIN_ROBOT

    headers = {"Content-Type": "application/json; charset=utf-8"}

    payload = {
        "msgtype": "text",
        "text": {
            "content": msg
        },
        "at": {
            "atMobiles": []
        }
    }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers)
    return response.text


def send_sms(msg):
    url = SMS_URL
    payload = {
        "tos": PHONE_NUMBERS,
        "service": MODULE_NAME,
        "content": msg}
    headers = {
        'Content-Type': "application/json",
    }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, timeout=3)
    return response.text


def monitor_run(num=4):
    log_path = '{0}/{1}_{2}.log'.format(LOG_DIR, MODULE_NAME, get_cur_strtime("%Y-%m-%d"))
    line_no = 0  # 记录数据读取行数
    log_cache = '{0}/{1}_{2}log.cache'.format(LOG_DIR, MODULE_NAME, get_cur_strtime("%Y-%m-%d"))

    while True:
        try:
            with open(log_path, 'r') as f:
                lines = f.readlines()

                if lines[line_no::]:
                    lines_add = lines[line_no::]
                    line_no = len(lines)
                else:
                    lines_add = lines
                    line_no = len(lines)

                for line in lines_add:
                    try:
                        post_data = '{}'.format(line)

                        level = post_data.split(" ")[2].strip()
                        # err_str = '{}'.format(line.split('{0}: {1}'.format(MODULE_NAME, level))[1])
                        # err_dict = eval(err_str)
                        # err_url = err_dict.get('request_url', '')
                        time_hour = line.split(' ')[1].split(':')[0]
                        date = line.split(' ')[0]
                        key = md5('{0}{1}{2}'.format(date, int(time_hour), level))
                        keys = list()
                        keys.append(key)

                        for i in range(1, num):
                            keys.append(md5('{0}{1}{2}'.format(date, int(time_hour) + i, level)))

                        try:
                            with open(log_cache, 'r') as read_cache:
                                hash_map = read_cache.readlines()  # 讀取已告警的緩存信息
                            if '{}\n'.format(key) not in hash_map:

                                if level == "CRITICAL":
                                    try:
                                        logger.info("monitor_run warning: {}".format(post_data))
                                        send_sms("{}服务不可用,详情查看监控群告警".format(MODULE_NAME))
                                        call_din(post_data)
                                        # print(post_data)
                                    except:
                                        call_din(post_data)
                                        # print(post_data)

                                else:
                                    call_din(post_data)
                                    # print(post_data)
                                with open(log_cache, 'a') as write_cache:
                                    for key in keys:
                                        write_cache.write('{}\n'.format(key))
                        except FileNotFoundError:
                            # print("leaver=====", lever)
                            if level == "CRITICAL":
                                try:
                                    send_sms("{}服务不可用,详情查看监控群告警".format(MODULE_NAME))
                                    call_din(post_data)
                                    # print(post_data)
                                except:
                                    call_din(post_data)
                                    # print(post_data)
                            else:
                                call_din(post_data)
                                # print(post_data)
                            with open(log_cache, 'a') as write_cache:
                                for key in keys:
                                    write_cache.write('{}\n'.format(key))
                    except Exception:
                        print(traceback.format_exc())
                        continue

        except FileNotFoundError:
            continue
        time.sleep(5)


if __name__ == '__main__':
    monitor_run(4)
    # send_sms("服务不可用,详情查看{}监控群告警".format(MODULE_NAME))
