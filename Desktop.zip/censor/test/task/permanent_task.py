#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import traceback
import unittest

from test import get_root_dir
from share.ob_log import logger
from share.parse_json import ParseJson

info = ParseJson.loads(get_root_dir() + "/config.json")
CASE_DIR = get_root_dir() + info.get('case_dir')
REPORT_DIR = get_root_dir() + info.get('report_dir')
MODULE_NAME = info.get("service_name", '')


def all_case():
    test_dir = CASE_DIR  # "测试用例存放目录"
    discover = unittest.defaultTestLoader.discover(test_dir, pattern='test*.py', top_level_dir=None)
    return discover


def case_run():
    while True:
        try:
            need_test_cases = all_case()
            logger.debug("permanent task start: {}".format(need_test_cases))
            unittest.TextTestRunner().run(need_test_cases)
            time.sleep(5)
        except Exception:
            print("error:", traceback.format_exc())
            pass


if __name__ == "__main__":
    case_run()
