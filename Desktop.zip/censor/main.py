# coding=utf-8
"""
author = jamon
"""

import asyncio
import logging
import os
import sys

from threading import Thread

from share.ob_log import logger

rootPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(rootPath)


if __name__ == "__main__":
    from share.parse_json import ParseJson
    info = ParseJson.loads("config.json")
    num = info.get('num', 4)

    logger.init(module_name=info.get("service_name"), log_dir=info.get("log_dir", "../logs/")
                , level=info.get("log_level", logging.DEBUG))

    from test.task.permanent_task import case_run
    from test.task.monitor import monitor_run
    from test.task.daily_task import daily_task

    t1 = Thread(target=case_run)
    t1.start()
    t2 = Thread(target=monitor_run, args=(num,))
    t2.start()
    t3 = Thread(target=daily_task)
    t3.start()
