使用说明：

拷贝整个notify目录至自己的项目下

from notify import Notify

Notify类包含4个静态方法，一些比较固定的参数写在了配置文件config.json(联系人电话，钉钉机器人地址)

1.发送钉钉消息：
Notify.send_ding(content='这是传入的消息')

2.发送短信消息：
Notify.send_sms(service='消息标题',content="消息内容不超过20字符")

3.发送文字转语音消息：
Notify.send_vms(name="你的名字",service="消息内容不超过20字符")

4.发送邮件：
Notify.send_mail(content="邮件内容text", title="邮件标题", recv="邮件接收人多个“，”隔开")