#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import json
import traceback
from notify.config import G_CONFIG

notify_config = G_CONFIG.notify
uri = notify_config["uri"]
ding_url = notify_config["ding_url"]
tos = notify_config["phone_numbers"]
tts_code = notify_config["tts_code"]
template_code = notify_config["template_code"]


class Notify(object):
    """
    各种通知服务的调用
    """

    @classmethod
    def send_ding(cls, content):
        """
        钉钉通知
        :param uri:
        :param content:
        :param ding_url:
        :return:
        """
        url = uri + "/notify/send_ding"
        data = {"content": content, "ding_url": ding_url}
        headers = {"Content-Type": "application/json"}
        try:
            response = requests.request("post", url, data=json.dumps(data), headers=headers)
            return response.text
        except:
            print(traceback.format_exc())
            return

    @classmethod
    def send_sms(cls, service, content):
        """
        发送短信通知
        :param uri:
        :param content:
        :param tos:
        :param service:
        :return:
        """
        url = uri + "/notify/send_sms"
        data = {"template_code": template_code, "content": content, "tos": tos, "service": service}
        headers = {"Content-Type": "application/json"}
        try:
            response = requests.request("post", url, data=json.dumps(data), headers=headers)
            return response.text
        except:
            print(traceback.format_exc())
            return

    @classmethod
    def send_vms(cls, service, name):
        """
        发送短信通知
        :param uri:
        :param content:
        :param tos:
        :param service:
        :return:
        """
        url = uri + "/notify/send_vms"
        data = {"tts_code": tts_code, "name": name, "tos": tos, "service": service}
        headers = {"Content-Type": "application/json"}
        try:
            response = requests.request("post", url, data=json.dumps(data), headers=headers)
            return response.text
        except:
            print(traceback.format_exc())
            return

    @classmethod
    def send_mail(cls, content, title, recv):
        """
        发送邮件通知
        :param uri:
        :param content:
        :param title:
        :param recv:
        :return:
        """
        url = uri + "/notify/send_mail"
        data = {"content": content, "title": title, "recv": recv}
        headers = {"Content-Type": "application/json"}
        try:
            response = requests.request("post", url, data=json.dumps(data), headers=headers)
            return response.text
        except:
            print(traceback.format_exc())
            return


if __name__ == "__main__":

    print(Notify.send_ding(content='这是测试'
                           )
          )

    print(Notify.send_sms(
                          service='测试',
                          content="这是测试"
                          )
          )

    print(Notify.send_vms(
                          name="oldboy",
                          service="测试"
                          )
          )
