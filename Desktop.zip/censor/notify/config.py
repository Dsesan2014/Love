# coding=utf-8

from share.parse_json import ParseJson


class Config(object):
    """
    全局配置信息
    """

    def __init__(self):
        self.info = ParseJson.loads('config.json')

    def update(self):
        self.info = ParseJson.loads('config.json')

    @property
    def notify(self):
        """
        返回通用notify配置
        :return: {                //告警通知配置
            "service":"蜜罐数据",        //被监控的服务的名称
            "uri": "http://47.106.87.127:9090",  //告警服务所在的ip+端口
            "ding_url": "https://oapi.dingtalk.com/robot/send?access_token=527f0732f0f945045868302f666a3684d92898a7b91d5af8545f3d6aa71aaa48", //钉钉告警人地址
            "phone_numbers":"13812345678,13812345679", // 短信接收人
            "recv": "jamon@oldboy.com", //邮件接收人
        }

        """
        return self.info['notify']


G_CONFIG = Config()


if __name__ == "__main__":
    print(G_CONFIG.notify)
