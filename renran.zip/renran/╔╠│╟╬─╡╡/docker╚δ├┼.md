# docker入门

### 1. docker初识

#### 1.1 为什么要用docker?

![image-20191114200429049](assets/image-20191114200429049.png)

![image-20191114200429049](assets/image-20191114200529108.png)

![image-20191114200857594](assets/image-20191114200857594.png)

#### 1.2. docker容器的优势

```
更高效的利用系统资源
更快速的启动时间
一致的运行环境
持续交付和部署
更轻松的迁移
```



### 2 docker三大概念

```
容器三大基本概念
镜像 image
容器 container
仓库 repository
docker整个生命周期就是这三个概念。
```



### 3. docker安装

有两种安装方法

#### 3.1 第一种 官方安装(版本比较新, 但是可能比较慢)

官方教程如下，最正确安装docker姿势, 如果想要安装官方版本就使用此方法

```
1.卸载旧版本
sudo yum remove docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-selinux docker-engine-selinux docker-engine

2.设置存储库
sudo yum install -y yum-utils device-mapper-persistent-data lvm2

sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

3.安装docker社区版
sudo yum install -y docker-ce

4.启动关闭docker
systemctl start docker
```

#### 3.2 第二种 使用阿里云的源, 下载安装速度很快，但版本不是最新

##### 3.2.1 确认阿里云的yum源文件

```
vim /etc/yum.repos.d/Centos-7.repo
```

##### 3.2.2 使用yum开始安装docker

```
yum install -y docker
```

##### 3.2.3 查看docker安装版本

```
rpm -qi docker
```



### 4. docker基本使用命令

##### 4.1.1  搜索网上的docker镜像

```
docker search hello-world
```

##### 4.1.2 下载docker镜像

```
docker pull docker.io/hello-world
```

##### 4.1.3  查看docker镜像

docker官方更新了很多命令，不用慌，这两个命令效果是一样的，用哪个都行

```
docker images
docker image ls
```

##### 4.1.4 运行docker镜像

```
docker run fce
```

##### 4.1.5  查看正在运行的docker容器

```
docker container ls
```

##### 4.1.6  查看已经运行过的容器

```
docker ps -a
```

注意： 如果docker容器里面没有任何后台程序运行的话，容器就会退出，挂掉

注意： 如果docker容器里面没有任何后台程序运行的话，容器就会退出，挂掉

注意： 如果docker容器里面没有任何后台程序运行的话，容器就会退出，挂掉

##### 4.1.7  配置docker镜像加速器

```
https://www.daocloud.io/mirror#accelerator-doc

# 一条命令加速
curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361db2.m.daocloud.io

# 这条命令其实就是改了docker的一个配置文件里面的注册镜像地址, 可以查看一下
cat /etc/docker/daemon.json
```

注意： 这里会遇到一个坑，上面的加速器命令会修改我们的/etc/docker/daemon.json文件, 里面是一个字典，这个字典里面有语法错误，导致docker无法启动(原因是因为多了一个逗号)

注意： 这里会遇到一个坑，上面的加速器命令会修改我们的/etc/docker/daemon.json文件, 里面是一个字典，这个字典里面有语法错误，导致docker无法启动(原因是因为多了一个逗号)

注意： 这里会遇到一个坑，上面的加速器命令会修改我们的/etc/docker/daemon.json文件, 里面是一个字典，这个字典里面有语法错误，导致docker无法启动(原因是因为多了一个逗号)

##### 4.1.8  容器是运行应用程序的，所以必须要先有一个操作系统为基础

运行一个在后台的任务

```
docker run -d centos /bin/sh -c "while true;do echo 爱滴魔力转圈圈; sleep 1;done"
```

##### 4.1.9  不间断打印容器的日志信息 

```
docker logs -f 容器ID
```

##### 4.1.10 进入容器命令(容器是有自己的微型操作系统的。微型linux)

```
docker exec -it e80 /bin/bash
```

##### 4.1.11 交互式的运行一个容器，且进入容器(也就是开启并进入一个新的容器)

```
docker run -it centos /bin/bash
```

假如你没有centos这个镜像的话，它会自动从网上下载下来并运行

##### 4.1.12 删除docker镜像

```
docker rmi 镜像ID
```

注意: 可能会无法成功删除， 它会提示这个镜像有一个依赖镜像，你需要先删除这个依赖镜像，再删除此镜像

##### 4.1.13  提交创建自定义的镜像(docker container commit)

```
1.我们进入交互式的centos容器中，发现没有vim命令
　　docker run -it centos /bin/bash
2.在当前容器中，安装一个vim
　　yum install -y vim
3.安装好vim之后，exit退出容器
　　exit
4.查看刚才安装好vim的容器记录
　　docker container ls -a
5.提交这个容器，创建新的image
　　docker commit 059fdea031ba tiger/centos-vim
6.查看镜像文件
[root@master /home]docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
tiger/centos-vim   latest              fd2685ae25fe        5 minutes ago       348MB
```

##### 4.1.14 导出镜像

```
docker save centos > /opt/centos.tar.gz
```

##### 4.1.15 导入镜像

```
docker load < /opt/centos.tar.gz
```

##### 4.1.16 启动容器

```
docker start 容器ID
```

##### 4.1.17 停止容器

```
docker stop 容器ID
```

##### 4.1.18 新建容器并且启动

1 新建一个容器并输出hehe

```
docker run centos /bin/echo "hehe"  # 这跟在本地直接执行 /bin/echo'hehe'
```

2 新建容器并自定义一个名字qishi

```
docker run --name qishi -it centos /bin/bash  # 启动一个bash终端,允许用户进行交互。
```

##### 4.1.19 运行一个ubuntu容器

```
docker run -it ubuntu /bin/bash
```

![1568948768996](assets/1568948768996.png)

##### 4.1.20 查看所有的docker容器ID和镜像ID

```
# 查看所有的docker容器记录ID
docker ps -aq

# 查看所有的docker镜像ID
docker images -aq

# 删除所有的已经运行过的docker容器记录
docker rm `docker ps -aq`

# 删除所有的docker镜像
docker rmi `docker images -aq`
注意: 这个引号不是单引号，是1左边的这个小写符号
```

##### 4.1.21 查看指定容器的端口映射

```
docker port 74a
```

​     查看容器内的进程

```
docker top 74a
```

##### 4.1.22 外部访问容器

1 在容器内跑一个app.py程序, 运行在5000端口

2  使用-P参数随机映射一个端口到虚拟机上

docker run -d -P training/webapp python app.py
​    -P 参数会随机映射端口到容器开放的网络端口

​    如果本地没有这个镜像，docker run会自动为我们下载镜像

3 使用-p参数自定义一个端口到虚拟机上， 如9000端口

```
docker run -d -p 9000:5000 training/webapp python app.py
```

4  我们可以通过虚拟机的IP 192.168.12.249加端口9000进行访问



##### 4.1.23 发布docker image到仓库

1 docker提供了一个类似于github的仓库dockerhub,
网址https://hub.docker.com/需要注册使用
2 注册docker id后，在linux中登录dockerhub

```
docker login
```

注意要保证image的tag是账户名，如果镜像名字不对，需要改一下tag

```
docker tag tiger/centos-vim lxh661314/centos-vim
```

语法是：  docker tag   仓库名   lxh661314/仓库名

3 推送docker image到dockerhub

```
docker push lxh661314/centos-cmd-exec:latest
```

4 在dockerhub中检查镜像
https://hub.docker.com/
5 删除本地镜像，测试下载pull 镜像文件

```
docker rmi -f d69
docker pull lxh661314/centos-entrypoint-exec
```

删除镜像和下载镜像



### 5. 私有仓库

#### 5.1 私有仓库搭建

##### 5.1.1 官方提供的私有仓库docker registry用法

```
https://yeasy.gitbooks.io/docker_practice/repository/registry.html
```

##### 5.1.2 一条命令下载registry镜像并且启动私有仓库容器

```
docker pull registry
```

私有仓库会被创建在容器的/var/lib/registry下，因此通过-v参数将镜像文件存储到本地的/opt/data/registry下
端口映射容器中的5000端口到宿主机的5000端口

```
docker run -d -p 5000:5000 -v /opt/data/registry:/var/lib/registry registry
```

##### 5.1.3 检查启动的registry容器

```
docker ps
```

##### 5.1.4 测试连接容器

```
telnet 192.168.1.197 5000
```

##### 5.1.5 修改镜像tag,以docker registry的地址端口开头

```
docker tag registry 192.168.12.135:5000/qishi-registry

```

##### 5.1.6 查看docker镜像，找到registry的镜像

```
docker images
```

##### 5.1.7 Docker 默认不允许非 HTTPS 方式推送镜像。我们可以通过 Docker 的配置选项来取消这个限制，这里必须写正确json数据

```
[root@master /]# cat /etc/docker/daemon.json
添加一行配置
{
    "registry-mirrors": ["http://f1361db2.m.daocloud.io"],
    "insecure-registries":["192.168.12.249:5000"]
}

```

写入到docker服务中，写入到[Service]配置块中，加载此配置文件

```
vim /lib/systemd/system/docker.service
```

添加一行配置

```
EnvironmentFile=-/etc/docker/daemon.json
```

##### 5.1.8 修改了docker配置文件，重新加载docker

```
systemctl daemon-reload
```

##### 5.1.9 重启docker

```
systemctl restart docker
```

**注意，重启docker服务，所有的容器都会挂掉**

**注意，重启docker服务，所有的容器都会挂掉**

**注意，重启docker服务，所有的容器都会挂掉**

##### 5.1.10 重启了docker，刚才的registry容器进程挂掉了，因此重新启动它

```
docker ps -a
docker start 容器id
```

##### 5.1.11 推送本地镜像

```
192.168.12.135:5000/qishi-registry 
```

##### 5.1.12 由于docker registry没有web节目，但是提供了API数据

要想查看已经上传的镜像， 通过以下链接访问即可查看:

```
官网教程：https://docs.docker.com/registry/spec/api/#listing-repositories
curl http://192.168.12.249:5000/v2/_catalog
或者浏览器访问http://192.168.12.249:5000/v2/_catalog
```

##### 5.1.13 删除本地镜像，从私有仓库中下载

先修改一个镜像的标签

```
docker tag qishi/centos-vim 192.168.12.135:5000/qishi-centos-vim
```

上传镜像

```
docker push 192.168.12.135:5000/qishi-centos-vim
```

删除本地镜像

```
docker rmi -f `docker images -aq`
```

下载镜像

```
docker pull 192.168.12.249:5000/hello-world
```

### 6. 利用dockerfile定制镜像

##### 6.1 一个简单的shell脚本

```
cd /opt
mkdir hehe2
cd hehe2
touch hehe.py
echo "print('呵呵你妹啊~~~')" > hehe.py
python3 hehe.py
```

##### 6.2 dockerfile基本使用

```
1. FROM参数(指定基础镜像)
FROM scratch # 制作base image基础镜像，尽量使用官方的image作为base image
FROM centos # 以centos为基础镜像，进行二次构建镜像
FROM ubuntu:14.04 # 带有tag的base image

2. LABEL参数(标签, 定义作者信息)
LABEL version=“1.0” # 容器元信息，帮助信息，Metadata，类似于代码注释
LABEL maintainer=“lxh661314@163.com"

3. RUN参数(是一个万能指令，执行命令)
#对于复杂的RUN命令，避免无用的分层，多条命令用反斜线换行，合成一条命令！
RUN yum update && yum install -y vim \
    Python-dev # 反斜线换行
RUN /bin/bash -c "source $HOME/.bashrc;echo $HOME”

4. WORKDIR参数(相当于linux的cd命令)
WORKDIR /root # 相当于linux的cd命令，改变目录，尽量使用绝对路径！！！不要用RUN cd
WORKDIR /test # 如果没有就自动创建
WORKDIR demo # 再进入demo文件夹
RUN pwd     # 打印结果应该是/test/demo

5. ADD参数(把宿主机的一个文件，添加到容器空间内)
ADD /opt/django/manage.py /opt/  # 把宿主机的/opt/django/manage.py放到容器空间内的/opt/目录下
ADD /opt/python3.6.tar.gz /opt/  # ADD的解压文件作用，将宿主机的/opt/下的python3.6.tar.gz解压到容器内的/opt/目录下
ADD and COPY
ADD hello /  #把本地文件添加到镜像中，吧本地的hello可执行文件拷贝到镜像的/目录
ADD test.tar.gz /  #添加到根目录并解压

WORKDIR /root
ADD hello test/  # 进入/root/ 添加hello可执行命令到test目录下，也就是/root/test/hello 一个绝对路径
COPY hello test/  # 等同于上述ADD效果

6. COPY参数(拷贝指令)
# 将宿主机的文件, 拷贝到容器内，但是没有解压缩的命令，尽量使用COPY,不要使用ADD
COPY filename /opt/

ADD与COPY
   - 优先使用COPY命令
    -ADD除了COPY功能还有解压功能
添加远程文件/目录使用curl或wget

7. ENV参数(docker的环境参数指令)
ENV # 环境变量，尽可能使用ENV增加可维护性
ENV MYSQL_VERSION 5.6 # 设置一个mysql常量,这个${MYSQL_VERSION}类似于全局常量
RUN yum install -y mysql-server=“${MYSQL_VERSION}”  # 如果版本号有变更，则只需要改这个常量就可以了
```

##### 6.3 使用dockerfile自定制django镜像

参照博客： https://www.cnblogs.com/tiger666/articles/10671509.html

在/opt/docker目录下面准备文件

![1573791133620](assets/1573791133620.png)

dockerfile配置文件

```
FROM centos
MAINTAINER TigerLee

ADD CentOS-Base.repo /etc/yum.repos.d
ADD epel.repo /etc/yum.repos.d
RUN yum clean all
RUN yum makecache
RUN yum update -y

RUN yum install -y python36
RUN yum install -y python36-pip
RUN pip3 install setuptools
ADD Django-2.1.7.tar.gz /opt/

WORKDIR /opt/
RUN mv Django-2.1.7 django

WORKDIR /opt/django
RUN python3 setup.py install

WORKDIR /opt
RUN django-admin.py startproject qishidj

ADD run.sh /opt/qishidj/run.sh
RUN sed -i "s/ALLOWED_HOSTS = \[\]/ALLOWED_HOSTS = \['\*'\]/g" /opt/qishidj/qishidj/settings.py
WORKDIR /opt/qishidj
RUN chmod 777 run.sh
EXPOSE 8000
CMD ["/bin/sh","run.sh"]
```



### 7. 今日作业

```
1 在https://hub.docker.com/这个网站注册一个docker账号
2 搭建一个私有仓库，支持docker镜像的上传和下载
3 使用dockerfile定制一个可以直接访问django项目的镜像
```

