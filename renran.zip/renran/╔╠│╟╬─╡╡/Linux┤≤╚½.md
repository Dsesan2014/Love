# 1.Linux系统安装

## 	1下载centos镜像

​		下载地址：

```
https://opsx.alibaba.com/mirror  
# 阿里云官方镜像站
iso下载地址（此DVD映像包含可以使用该软件安装的所有软件包安装程序。这是大多数用户的推荐图像。）：
https://mirrors.aliyun.com/centos/7/isos/x86_64/CentOS-7-x86_64-DVD-1810.iso
```

# 2.Linux初始

## 	1.基本设置

```
hostnamectl set-hostname qishi
```

## 	2.查看当前工作目录

```
pwd
```

## 	3.查看ip的命令

```
ifconfig
```

## 	4.重启网卡服务

```
systemctl start network    #启动网络服务
systemctl restart network   #重启网络服务
systemctl stop network   #停止网络服务
```

## 	5.启动网卡

```
命令语法: ifup 网卡名
ifup ens33  # 启用网卡
ifdown ens33  # 停止网卡
# ens33就是网卡名
```

注释   ：但是这里有一个问题，每一次系统启动之后都需要去启用网卡，不然就没办法连接网络并获取IP地址。

解决办法：

（1）打开网卡配置文件

```
vim /etc/sysconfig/network-scripts/ifcfg-ens33
```

（2） 按i进入编辑模式

（3） 讲最后一行ONBOOT=no 改成 ONBOOT=yes ,退出保存。

（4）init 6 重启服务器即可





# 3.Linux目录结构初识

## 	1.linux基本指令操作

```
cd  切换目录
pwd  查看当前工作目录
.    当前目录
..   上一层目录
-    前一个工作目录
~    当前【用户】所在的家目录
mkdir  创建文件夹
touch  创建文件
rm -rf   删除文件
mv    移动或重命名文件
ls   查看目录下的文件名
ls -la   查看目录下的文件以及隐藏文件
cat   查看文件内容
tail -f   监控文件内容
more   分页查询文件内容
less   查看文件内容
ctrl+l   清理终端显示
Ctrl+c   终止当前操作
```



## 	2.linux开关机命令

​		shutdown    关机

​		init 6      重启命令

​		reboot    重启



## 	3.创建用户命令

```
useradd huangwen
passwd huangwen
```





## 4.防火墙设置

```
systemctl stop firewalld   # 先临时关闭防火墙
systemctl disable firewalld  # 再永久关闭防火墙

```

```
# 临时关闭
getenforce  # 查看状态(0表示关闭 1表示开启)
setenforce 1/0  # 表示开启/关闭

# 永久关闭
vim /etc/selinux/config
# 修改
SELINUX=disabled
```





## 5.指令详解

​	创建多个目录命令

```
mkdir -p
mkdir -p /root/qishi5/gaoxin/{1,2,3}  # 创建多个目录，放在大括号里面用逗号隔开，千万要注意不能有空格
touch /root/qishi5/gaoxin{1,2,3} # 创建多个普通文件
```



​	vim指令、

```
vi/vim操作流程: 
1. vi 打开文件 此时进入命令模式，你可以输入 i/a/o 命令，进入编辑模式
2. 在编辑模式下，开始输入字符串
3. 写完之后， 按下 esc 回到命令模式，按下 : 进入底线命令模式
4. :w 写入不退出 :wq! 写入且强制退出
```

```
底线命令模式 
w 保存
q 退出
wq 保存退出
q! 无理由退出
wq! 无理由保存退出 
```



​	cat 命令

```
cat -n 文件名  查看文件，并显示行号

cat 文件名  查看文件

# 追加文字到文件
cat >>/tmp/oldboy.txt << EOF
难难难 道德玄
不对知音不可谈
对了知音谈几句
不对知音枉费舌尖
EOF
```



​	more和less命令

主要用来查看大容量的文件

```
more /etc/passwd
按下空格space是翻页，
按下b键是上一页
回车键向下读取内容
```



cp 命令    复制文件或文件夹

```
复制 > copy > cp
# 移动xxx.py到/tmp目录下
cp xxx.py /tmp/
# 移动xxx.py到tmp下顺便改名为tiger.py
cp xxx.py /tmp/tiger.py
```

```
cp -r     递归，复制目录以及目录的祖孙后代
cp -p     复制文件 ，同事保持文件属性不变
```





alias 命令     起别名

```
alias  命令查看别名

alias  rm="rm -i"
```





find  查找命令

查找想要的文件，过滤掉不需要的文件。

```
-name 按照文件名查找文件
-type 查找某一类型的文件，诸如：
b - 块设备文件。
d - 目录。################
c - 字符设备文件。
p - 管道文件。
l - 符号链接文件。#############
f - 普通文件。#################
s - socket文件
```

```
# 找出/tmp所有以 .txt 结尾的文件
find /tmp/ -type f -name "*.txt"

# 找到/etc下所有名字以host开头的文件
find /etc -name 'host*'

# 找到/opt上一个名为settings.py
find /opt -name 'settings.py'
```





netstat -tunlp  表示查看当前系统开放的所有端口

ps -ef | grep nginx    过滤出所有nginx关键字的进程



远程copy命令

用户linux之间的文件或者目录的远程传输

```
语法
scp 【可选参数】 本地源文件 远程文件标记

scp 本地文件  远程用户名@远程ip:远程文件夹/
scp 本地文件  远程用户名@远程ip:远程文件夹/远程文件名
scp -r  本地文件夹  远程用户名@远程ip:远程文件夹/

scp Python-3.6.6.tgz 192.168.1.189:/opt/  # 将文件拷贝到远程机器上
scp 192.168.1.189:/opt/5Python-3.6.6.tgz . # 将远程机器上的文件拷贝到本地
```

0

参数

```
-r :递归复制整个目录
-v:详细方式输出
-q:不显示传输进度条
-C：允许压缩
```

```
scp -v -r /opt 192.168.1.155:/tmp/  
# 递归拷贝opt目录到远程服务器上(显示详细输出,如debug信息)
scp -r /opt 192.168.1.155:/tmp/   # 递归拷贝opt目录到远程服务器上
scp -C -r /opt 192.168.1.155:/tmp/   # 递归拷贝opt目录到远程服务器上，并压缩传输
```





du命令   用于显示目录或者文件的大小

```
du 【参数】【文件或目录】
-s 显示总计
-h 以k，M,G为单位显示，可读性强

df -h 查看磁盘大小， 和占用空间
```



top 命令，动态监视进程活动与系统负载等会信息



文件加锁解锁

```
chattr +a test.py
chattr -a test.py
```





linux时间同步

```
//手动修改时间
date 091117152019   # 0911表示月和日, 1715表示时分, 2019表示年份

//以系统时间为基准，修改硬件时间
[root@oldboy_python ~ 10:29:07]#hwclock -w

//以硬件时间为基准，修改系统时间
[root@oldboy_python ~ 10:29:21]#hwclock -s
```





## 6.上传下载

​	lrzsz 工具包（可以提供linux服务器的上传和下载）

```
yum install lrzsz   # 下载此工具包

rz   # 上传文件
sz   # 下载文件
```



​	上传下载命令

```
wget命令用于在终端下载网络文件
参数是 wget [参数] 下载地址
wget -r -p http://www.luffycity.com#递归下载路飞所有资源，保存到www.luffycity.com文件中
```





## 7.vim基本命令

```
w(e)  移动光标到下一个单词
b     移动到光标上一个单词
0（数字0）  移动到本行开头
$      移动光标到本行结尾
H      移动光标到屏幕首行
M      移动到光标到屏幕的中间一行
L      移动光标到屏幕的卫星
gg     移动光标到文档的首行
G      移动光标到文档的尾行


yy    拷贝光标所在行**
nyy   拷贝以光标开始往下数n行内容**
dd    删除光标所在行**
D     删除当前光标到行尾的内容
dG    删除当前行到文档尾部的内容
p     粘贴yy所复制的内容**
x　　 删除光标所在的前一个字符
del键 删除光标所在的字符**
u     撤销上一步的操作**



q!     强制退出**
wq!    强制写入退出**
set nu 显示行号
set nonu 取消显示行号
:数字　　调到数字那行
随时按下esc可以退出底线命令模式**
```







# 4.用户管理与文件权限

## 	1.普通用户授权	

​		root 用户

​	修改/etc/sudoers 文件，文件非常重要，不可以随意修改

```
vim /etc/sudoers
```

​	如果想要给用户权限赋予权限，使用命令

```
visudo
```

​	修改完成后，需要重载文件，使用命令

```
source /etc/sudoers
```





## 	2.文件与目录权限

​		文件权限详解

```
对于普通文件来说:
r  可以读文件
w  可以写入或编辑文件
x  可以执行

对于目录来说
r  可以查看文件内容
w  可以创建和修改目录里面的文件
x  表示可以进入目录
```



​	执行文件方法

```
./文件名
例： ./tiger.sh
```



​	配置权限

```
chmod u+r tiger  给用户添加读的权限
chmod u+w tiger  给用户添加写的权限
chmod u+x tiger  给用户添加执行的权限

chmod g+r tiger  给组添加写的权限
chmod g+w tiger  给组添加写的权限
chmod g+x tiger  给组添加写的权限

chmod o+r tiger 给其他人添加读的权限
chmod o+w tiger 给其他人添加写的权限
chmod o+x tiger 给其他人添加执行的权限
```



​	chmod 修改权限

```
chmod 777 wcx.py
```



​	chmod修改属主和属组

```
chown root yuanxin.sh
# 以下这两个命令都是同样的效果:
chown root:root yuanxin.sh
chown root.root yuanxin.sh
```



## 	3软链接

​		配置环境变量

```
echo $PATH  #查看环境变量
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin
```



​		添加软链接

```
ln -s /opt/python3.6/bin/python3 /usr/bin/python3
ln -s /opt/python3.6/bin/pip3 /usr/bin/pip3
```





## 	4.tar压缩解压命令

​	参数详解

```
-z  使用gzip工具进行压缩

-x  解压文件

-v  显示详细信息

-c  压缩文件

-f  指定文件
```

​	

​	压缩文件命令

```
tar -cf 文件名
```



​	解压文件命令

```
tar -xvf
```

​	

​	通过gzip 命令进一步压缩（tar的重点）

```
tar -zcvf  压缩文件名  文件   #压缩文件
tar -zxvf  文件名        #解压.tar.gz文件
```



## 	



## 	5.netstat命令

​	查看所有端口指令

```
netstat -tunlp
```



​	端口详情

```
服务器端口范围: 0~65535

25和110 是邮件服务器的端口
3389 windows远程桌面端口
21 FTP
22 SSH的端口
23 telnet
53 DNS端口
67/68 DHCP协议端口
3306  mysql端口
139和445 windows下共享文件的端口
6379  redis端口
80 HTTP超文本传输协议端口
443 HTTPS
8000  Django默认端口
5000  flask默认端口
```



## 	

## 	6.DNS

​	DNS 域名解析系统

​	DNS工作原理

```
1， 我们想要访问www.baidu.com，首先会去本地DNS缓存中查找。
2.如果本地DNS缓存中没有，那就去本地文件hosts文件中查找。
3.如果本地hosts文件中也没有，那就去公网的DNS服务器中找。
4.如果公网的DNS服务器也没有的话，就去世界上的13个跟服务器去找
5，如果13个DNS跟服务器也没有的话，那就说明此域名没有注册，没办法访问。
```







## 	7.yum工具

RPM原理

能够从指定的服务器自动下载RPM包并且安装，可以自动处理依赖性关系，并且一次安装所有依赖的软件包



​	配置自定义yum源

​	先备份yum源

```
cd /etc/yum.repos.d
mkdir repo_bak
mv *.repo repo_bak/
```

​	

​	下载阿里云repo文件

```
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
```

​	

​	清空yum缓存并且生成新的yum缓存

```
yum clean all
yum makecache	
```

​	

​	安装软件扩展源

```
yum install -y epel-release
```









# 5.安装python3的步骤

## 	1.步骤

​	1，下载python3 源码包

```
wget https://www.python.org/ftp/python/3.6.6/Python-3.6.6.tgz
```



​	2.下载python3编译的依赖包

```
yum install -y gcc patch libffi-devel python-devel  zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel
```



​	3.解压源码包

```
tar -zxvf Python-3.6.6.tgz
```

​	

​	4.进入源码=包文件夹

```
cd Python-3.6.6
```



​	5.编译且安装

```
1.进入源码包目录
cd Python-3.6.6

2.ls查看源码包内容

3.释放编译文件 Makefile
./configure --prefix=/opt/python36

4.编译
make

5.编译安装,此步才会最终生成 /opt/python36/
make install
第4步和第5步可以合二为一, 使用以下命令即可
make && make install
注意: 从第2步到第5步一直是在Python-3.6.6目录下操作!!!!
注意: 从第2步到第5步一直是在Python-3.6.6目录下操作!!!!
注意: 从第2步到第5步一直是在Python-3.6.6目录下操作!!!!

6.进入/opt目录查看python36文件夹,我们要的python3都在这里了
```



​	6.更改linux的path变量，添加python3环境

```
1.echo $PATH
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin

2.环境变量配置文件:
vim ~/.bash_profile   # 用户环境变量控制文件
vim /etc/profile  # 系统环境变量控制文件
注意: 一定要将python3的目录放在第一位!!!!!!
注意: 一定要将python3的目录放在第一位!!!!!!
注意: 一定要将python3的目录放在第一位!!!!!!

3.为了永久生效path设置，添加到/etc/profile全局环境变量配置文件中
vim /etc/profile
在最后一行加入:
PATH=/opt/python36/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin

4.重载配置文件/etc/profile
source /etc/profile
```



​	7.安装Django模块

```
pip3 install -i https://pypi.douban.com/simple django==2.1.7
```



​	8.配置Django，把Django项目跑起来

```
(1) 创建一个django项目django-admin startproject qishi
(2) 配置settings.py文件，将ALLOW_HOST=[]改为ALLOW_HOST=["*"]
(3) 创建一个app   python3 manage.py startapp app01
(4) 启动django  python3 manage.py runserver 0.0.0.0:8000
```







## 	2.python虚拟环境安装



1.虚拟环境介绍

在使用python开发的过程中，工作一多，难免就会碰到不同的工程依赖不同版本的库的问题，或者是在开发过程中不想让物理环境里充斥各种各样的库，引来未来的依赖灾难，此时，我们需要对于不同的工程使用不同的虚拟环境来保持开发环境以及宿主环境的清洁。这里就需要使用到virtualenv，一个可以帮助我们管理不同的python环境的绝好工具，virtualenv可以在系统中建立多个不同并且相互不干扰的虚拟环境。



2.安装 虚拟环境

​	下载虚拟环境模块

```
pip3 install -i https://pypi.douban.com/simple virtualenv
```

​	

​	创建两个虚拟环境

```
virtualenv --no-site-packages --python=python3 qishi6
virtualenv --no-site-packages --python=python3 qishi7
```

​	

​	激活虚拟环境

```
source /opt/virtual_env/qishi6/bin/activate
```

  

​	进入虚拟环境，并且创建项目

```
source /opt/virtual_env/xiangge/bin/activate
cd /opt/qishi6
django-admin startproject qishi_1
```





​	确保开发环境的一致性

```
解决方案：
1.通过命令保证环境的一致性，导出当前python环境的包
pip3 freeze > requirements.txt   

这将会创建一个 requirements.txt 文件，其中包含了当前环境中所有包及 各自的版本的简单列表。
可以使用 “pip list”在不产生requirements文件的情况下， 查看已安装包的列表。

2.上传至服务器后，在服务器下创建virtualenv，在venv中导入项目所需的模块依赖
pip3 install -r requirements.txt
```



## 	3.安装virtualenvwrapper

​	注意: 一定要安装在python解释器本体下!!!

```
pip3 install virtualenvwrapper -i https://pypi.douban.com/simple
```



​	设置linux的用户配置文件配置virtualenvwrapper

vim ~/.bashrc

```
WORKON_HOME=~/Envs   # 设置virtualenv的统一管理目录, 以后自动下载的虚拟环境，全部都放在这
VIRTUALENVWRAPPER_VIRTUALENV_ARGS='--no-site-packages'   # 添加virtualenvwrapper的参数，生成干净隔绝的环境
VIRTUALENVWRAPPER_PYTHON=/opt/python347/bin/python3     # 指定python解释器的本体(注意此路径随不同的linux环境改变而改变)
source /opt/python34/bin/virtualenvwrapper.sh # 执行virtualenvwrapper安装脚本
```

注意： 后面的注释你得知道，但是不能放到配置文件里面去，不然会报错!!!



真实实验环境配置文件如下：

```
WORKON_HOME=~/Envs
VIRTUALENVWRAPPER_VIRTUALENV_ARGS='--no-site-packages'   VIRTUALENVWRAPPER_PYTHON=/opt/python36/bin/python3
source /opt/python36/bin/virtualenvwrapper.sh
```



重新加载

```
source ~/.bashrc
```





创建一个虚拟环境

```
mkvirtualenv xiangge
mkvirtualenv xiaqiang
mkvirtualenv zhenying
```



激活虚拟环境

```
workon xiangge
workon xiaqiang
workon zhenying
```



删除虚拟环境

```
rmvirtualenv xiaqiang
rmvirtualenv xiangge
rmvirtualenv zhenying
```









# 6.Centos下载安装MariDB

公司的免费技术栈

centos + python3 + django + vue + mysql + redis + celery + docker + git + nginx

收费的技术栈

oracle甲骨文 + SVN + redhat  + apache + mysql + django



## 	1.安装Mariadb

首先在/etc/yum.repos.d下创建一个MariaDB.repo文件

```
vim /etc/yum.repos.d/MariaDB.repo
```

添加一下配置

```
[mariadb]
name=MariaDB
baseurl=http://yum.mariadb.org/10.1/centos7-amd64
gpgkey=https://yum.mariadb.org/RPM-GPG-KEY-MariaDB
gpgcheck=1

使用一条命令下载安装Mariadb
yum install MariaDB-server MariaDB-client -y

```



安装好后，使用systemctl进行mariadb服务管理

```
systemctl start mariadb  #启动MariaDB
systemctl stop mariadb  #停止MariaDB
systemctl restart mariadb  #重启MariaDB
systemctl enable mariadb  #设置开机启动
```



初始化

```
mysql_secure_installation
```



优化解决中文无法正常显示的问题

```
1 停掉mariadb服务
	systemctl stop mariadb
2 修改配置文件vim /etc/my.cnf      #如下
```

```
[mysqld]
character-set-server=utf8
collation-server=utf8_general_ci
log-error=/var/log/mysqld.log
[client]
default-character-set=utf8
[mysql]
default-character-set=utf8
```







进入mysql，熟悉nysql相关操作

```
1 创建一个数据库oldboy
	create database oldboy
2 进入数据库oldboy
	use oldboy
3 创建一个表student
	create table student(id int(11),name varchar(20));
4 进入表student
	use student
5 插入一条数据
	insert into student(id, name) values(1, "三包春药");
6 查看这条数据，发现中文无法正常显示
```



查看数据库默认编码：

输入命令\s查看默认编码

```
MariaDB [(none)]> \s
--------------
mysql  Ver 15.1 Distrib 5.5.60-MariaDB, for Linux (i686) using readline 5.1

Connection id:		3
Current database:	
Current user:		root@localhost
SSL:			Not in use
Current pager:		stdout
Using outfile:		''
Using delimiter:	;
Server:			MariaDB
Server version:		5.5.60-MariaDB MariaDB Server
Protocol version:	10
Connection:		Localhost via UNIX socket
Server characterset:	utf8
Db     characterset:	utf8
Client characterset:	utf8
Conn.  characterset:	utf8
UNIX socket:		/var/lib/mysql/mysql.sock
Uptime:			4 min 56 sec

Threads: 1  Questions: 26  Slow queries: 0  Opens: 3  Flush tables: 2  Open tables: 28  Queries per second avg: 0.087
--------------

```



查看demo数据库的编码

```
show create database demo
```

查看demo表的编码

```
show create table demo 
```





# 7.redis

## 	1.redis简介

redis的有点：

​	属于内存型的数据库，存储速度非常快

redis的缺点：

​	断电数据会丢失

​	redis服务挂掉之后数据也会丢失

​	

## 	2.redis的安装

下载redis源码包

```
wget http://download.redis.io/releases/redis-5.0.2.tar.gz
```



解压文件

```
tar -zxvf redis-5.0.2.tar.gz
```



切换到redis源码目录

```
cd redis-5.0.2
```



编译源文件

```
make
```



编译好后，src/目录下有编译好的redis指令



make install安装到指定的目录，默认在/usr/local/bin

```
make install
```



创建redis配置文件

```
mkdir -p /opt/redis_conf
cd /opt/redis_conf
vim redis-6379.conf
```



添加一下配置

```
port 6379                         # 运行在6379的redis数据库实例
daemonize yes                     # 后台运行redis  
pidfile /data/6379/redis.pid      # 存放redis pid的文件
loglevel notice                   # 日志等级
logfile "/data/6379/redis.log"    # 指定redis日志文件的生成目录
dir /data/6379                    # 指定redis数据文件夹的目录
protected-mode yes                # 安全模式
requirepass   haohaio             # 设置redis的密码
```



在/跟目录创建文件夹

```
mkdir -p /data/6379
```



启动redis

```
redis-server /opt/redis_conf/redis-6379.conf
#或者
redis-server redis-6379.conf
```



连接redis

```
使用命令redis-cli进行连接
参数详解:
redis-cli  -p 6380  -a  haohaio
    -p  设置redis链接的端口
    -a  显示的填写密码
    --raw 使用原始格式
```







## 3. redis持久化

​	redis是内存型的数据库

redis数据放在内存中
重启服务器丢失数据
重启redis服务丢失数据
断电丢失数据

为了防止redis数据丢失，需要进行数据持久化，所有将数据写进一个文件中来实现。



RDB持久化

在配置文件中，添加rdb持久化参数

在redis-6379.conf 配置文件中写入如下配置

```
port 6379     
daemonize yes     
pidfile /data/6379/redis.pid
loglevel notice  
logfile "/data/6379/redis.log"
dir /data/6379   
protected-mode yes 
dbfilename dbmp.rdb

save 900 1                       # rdb机制 每900秒 有1个修改记录
save 300 10                      # 每300秒  10个修改记录
save 60 10000                    # 每60秒内  10000修改记录
```

修改完配置后，重启redis服务。

触发rdb持久化，可以手动save命令即可，生成dump.rdb持久化文件。

![](H:\深圳6期资料\Linux\day07\assets\1568855899592.png)



重启redis，数据不再丢失





AOF持久化

在配置文件中，添加aof功能

在redis-6379.conf中添加参数，开启aof功能

```
appendonly yes
appendfsync everysec

```



重启数据库，加载aof功能



redis持久化RDB转化为AOF

删除现有的AOF文件，备份RDB文件

```
cd /data/6379
rm -rf appendonly.aof
cp qishi5.rdb qishi5.rdb.bak

```



配置RDB切换到AOF

```
# 先进入redis客户端
redis-cli

# 配置开启AOF
127.0.0.1:6379> config set appendonly yes
# 关闭RDB
127.0.0.1:6379> config set save ""

```



以上配置重启后会失效，如果需要永久将RDB切换到AOF，还需要修改配置文件才可以。





# 8.nginx



## 	1.Nginx基础



WEB框架

django   大而全, 功能特别多 form表单 , ORM, 中间件  笨重，臃肿  600/s

flask  轻量级的，小而精, 它使用的都是第三方模块进行拼接起来的   4988/s

tornado  支持异步,  处理用户请求过来数据不用等待，类似于协程   2138/s



WEB服务器

nginx 开源的，支持高性能，高并发

apache   nginx他父亲

查看WEB服务器信息

curl -I www.jd.com



## 2.nginx安装

​	下载依赖库

```
yum install -y gcc patch libffi-devel python-devel zlib-devel bzip2-devel openssl openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel
```



​	下载nginx源码包

```
cd /opt
wget -c https://nginx.org/download/nginx-1.9.6.tar.gz
```



​	解压源码包

```
tar -zxvf nginx-1.12.0.tar.gz
```



​	释放编译文件，开启nginx状态监测功能

```
cd /opt/nginx-1.12.0
./configure --prefix=/opt/nginx112 --with-http_ssl_module --with-http_stub_status_module
```



​	编译安装

```
make && make install 
```



​	启动nginx，进入sbin目录，找到nginx启动命令

```
cd /opt/nginx112/sbin
./nginx #启动
./nginx -s stop #关闭
./nginx -s reload  # 平滑重启 ，修改了nginx.conf之后，可以不重启服务，加载新的配置
```



​	查看nginx运行状态

```
查看端口是否运行: netstat -tunlp
查看进程是否运行: ps -ef | grep nginx
```



nginx.conf配置文件解析

```
#定义nginx工作进程数
worker_processes  5;

#错误日志
#error_log  logs/error.log;

#http定义代码主区域
http {
    include       mime.types;
    default_type  application/octet-stream;
    #定义nginx的访问日志功能
    #nginx会有一个accses.log功能，查看用户访问的记录
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    #开启日志功能
    access_log  logs/access.log  main;
    sendfile        on;
    keepalive_timeout  65;
    #开启gzip压缩传输
    gzip  on;
    #虚拟主机1  定义一个 斗鱼网站 
    server {
        #定义nginx的访问入口端口，访问地址是  192.168.11.37:80
        listen       80;
        #定义网站的域名www.woshidouyu.tv
        #如果没有域名，就填写服务器的ip地址  192.168.11.37
        server_name  www.woshidouyu.tv;
        #nginx的url域名匹配
        #只要请求来自于www.woshidouyu.tv/111111111
        #只要请求来自于www.woshidouyu.tv/qweqwewqe
        #最低级的匹配，只要来自于www.woshidouyu.tv这个域名，都会走到这个location
        location / {
            #这个root参数，也是关键字，定义网页的根目录
            #以nginx安装的目录为相对路径  /opt/nginx112/html 
            #可以自由修改这个root定义的网页根目录
            root   html;
            #index参数定义网站的首页文件名，默认的文件名
            index  index.html index.htm;
        }
        #错误页面的优化(只要是遇到前面4系列的错误，就会直接跳转到相对目录下的40x.html页面)
        error_page  400 401  402  403  404   /40x.html;
    }
}
```



​	nginx启动出现错误的情况

如果在平滑启动nginx时出现以下情况，说明nginx没有启动，

nginx.pid failed

解决方案：

重新启动就可以



配置nginx多个虚拟主机

效果：

（1）访问三个不同域名，显示三个不同的网站

（2）三个网站互不影响

```
   worker_processes  5;

#error_log  logs/error.log;

events {
   worker_connections 1024;
}

http {
    include       mime.types;
    default_type  application/octet-stream;

    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
    access_log  logs/access.log  main;
    sendfile        on;
    keepalive_timeout  65;
    #gzip  on;
    server {
        listen       80;
        server_name  www.qishi5douyu.com;
        
        location / {
            root   /opt/web_server/douyu;
            index  index.html index.htm;
        }
        #error_page  404              /404.html;
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }   
    }   
    server {
        listen 80;
        server_name www.qishi5huya.com;
        location /{ 
            root /opt/web_server/huya;
            index index.html;
        }   
    }   
    server {
        listen 80;
        server_name www.qishi5zhanqi.com;
        location /{ 
            root /opt/web_server/zhanqi;
            index index.html;
        }   
    }   

}

```



在服务器上创建三个目录

```
cd /opt
rm -rf web_server
mkdir -p web_server/huya
mkdir -p web_server/douyu
mkdir -p web_server/zhanqi
touch web_server/huya/index.html
touch web_server/huya/index.html
touch web_server/huya/index.html
分别打开这三个index.html文件
vim index.html
分别添加三个直播网站的源代码内容
然后保存退出
```



修改本机hosts文件

```
c:\\windows\system32\drivers\etc\hosts
```



添加一下三行解析记录

```
192.168.1.197	www.qishi5douyu.com
192.168.1.197	www.qishi5huya.com
192.168.1.197	www.qishi5zhanqi.com
```



平滑启动nginx

```
/opt/nginx196/sbin/nginx -s reload
```



# 

# 9.mysql基本指令

```
1.启动mysql
systemctl start mariadb

2.linux客户端连接自己 
mysql -uroot -p -h 127.0.0.1

3.远程链接mysql服务端
mysql -uroot -p -h 192.168.1.197
远程授权:
grant all privileges on *.* to root@"192.168.1.100" identified by "redhat";
flush privileges

4.修改mysql密码
MariaDB [(none)]> set password = PASSWORD('redhat123');

5.创建mysql用户
create user xiaochun@'%' identified by 'xc666';

6.查询mysql库中的用户信息
use mysql;
select host,user,password from  user;

7.授权语句
给李俊这个用户，授予创建数据库的权限

mysql使用grant命令对账户进行授权，grant命令常见格式如下

grant 权限 on 数据库.表名 to 账户@主机名            对特定数据库中的特定表授权
grant 权限 on 数据库.* to 账户@主机名            　　对特定数据库中的所有表给与授权
grant 权限1,权限2,权限3 on *.* to 账户@主机名   　　 对所有库中的所有表给与多个授权
grant all privileges on *.* to 账户@主机名   　　 对所有库和所有表授权所有权限

#授予小春创建的权限，对于所有的库表生效
grant create  on *.* to xiaochun@"%"  identified by 'xc666';
#授予小春用户，只有创建mymysql数据库的权限
grant create  on mymysql.* to xiaochun@"%"  identified by 'xc666';

#授予用户最大的权限，所有的权限
grant all privileges on *.* to username@'%' identified by 'password';


8.移除权限
MariaDB [(none)]> revoke all privileges on *.* from xiaochun@"%" identified by 'xc666';


9.数据库的备份与恢复
#备份
mysqldump -u root -p --all-databases > /tmp/db.sql
#数据导入，方式有2种
source /tmp/db.sql;

第二种
mysql -uroot -p <  /tmp/db.sql 


第三种
navicat

第四种，如果你数据量特别大的话，使用第三方工具
xtrabackup
```







# 10.mariadb的主从复制

![](H:\深圳6期资料\Linux\day07\assets\1573611198238.png)

```
主从复制7步骤：
1.主数据库写入数据之后，会在data change记录
2.有变化记录之后，将增删改的一些SQL语句记录到本地的Binary log（二进制日志）中
3.在从库中一直开启一个进程
4.通过线程去读取这个二进制日志的内容
5.从库将读取到的数据写进自己的Relay log（中继日志中）
6.从库会将中继日志中的操作转化为SQL语句
7.通过转化的SQL语句写入到自己的数据库中，两边的数据就一致了。
```





mariadb 的主从复制

```
主服务器： 192.168.12.249
从服务器:  192.168.12.200
```



停止主服务器上的mariadb数据库服务

```
systemctl stop mariadb
```



修改主服务器配置文件

```
[mysqld]
server-id=1
log-bin=qishi-logbin
```



启动mariadb数据库

```
systemctl start mariadb
```



新建用于主从同步的用户demo，允许登录的从库是“192.169.12.249”

```
create user 'demo'@'%' identified by '123'
```



给从库账号授权，说明给demo从库复制的权限，在192.168.12.249机器上复制

```
grant replication slave on *.* to 'demo'@'%';
```



检查主库创建的复制账号

select user,host from mysql.user;



检查授权账号的权限

show grants for xiaochun@'%';



实现对主数据库锁表只读，防止数据写入，数据复制失败

```
flush table with read lock;
```





锁表后，一定要单独打开一个ssh窗口，导出主数据库的所有数据。



在主库上导出数据

```
mysqldump -u root -p --all-databases > /opt/qishimaster.sql
```





在从库上

关闭数据库服务

```
systemctl stop mariadb
```



在从库192.168.12.200上打开/etc/my.cnf

如果从库是新安装的数据库的话，没有中文配置，还需要添加中文配置

```
[mysqld]
character-set-server=utf8
collation-server=utf8_general_ci
log-error=/var/log/mysqld.log
[client]
default-character-set=utf8
[mysql]
default-character-set=utf8

server-id=3
read-only=true

```



重启数据库

```
systemctl restart mariadb
```



将主数据库的数据库文件拷贝到从库中

```
scp 192.168.12.249:/opt/qishimaster.sql /opt/
```



导入主数据库的数据文件后，保证从库的数据与主库数据一致。

```
mysql -u root -p
source /opt/qishimaster.sql
```



配置复制的参数，Slave从库连接Master主库的配置

```
mysql > change master to master_host='192.168.12.249',
master_user='lijun',
master_password='lj666',
master_log_file='qishi_logbin.000001',
master_log_pos=479;

```



启动从库的同步开关，测试主从复制的情况

```
start slave;
```



查看复制状态

```
show slave status\G;
```





最后在主数据库上操作

解锁主数据写入

```
unlock tables;

```





如果从库上面的普通用户无法在从库上登录，那就重新创建一个新的用户。

```
create user 'demo'@'%' identified by 'demo';
grant replication slave on *.* to 'demo'@'%';

```



或者在主库上给demo授权，只能授予查看的权限

```
grant select on *.* to demo@"%" identified by "123";
```







# 11.redis主从复制

redis主从同步原理：

![](H:\深圳6期资料\Linux\day07\assets\1568859896728.png)



```
1. 从服务器向主服务器发送 SYNC 命令。
2. 接到 SYNC 命令的主服务器会调用BGSAVE 命令，创建一个 RDB 文件，并使用缓冲区记录接下来执行的所有写命令。
3. 当主服务器执行完 BGSAVE 命令时，它会向从服务器发送 RDB 文件，而从服务器则会接收并载入这个文件。
4. 主服务器将缓冲区储存的所有写命令发送给从服务器执行。

\-------------
1、在开启主从复制的时候，使用的是RDB方式的，同步主从数据的
2、同步开始之后，通过主库命令传播的方式，主动的复制方式实现
3、2.8以后实现PSYNC的机制，实现断线重连
```



实现redis主从同步

准备三个redis数据库配置文件

背景：一主二从

6380为主，6381和6382 为从

```
cd /opt/redis_conf
vim redis-6380.conf
写入以下配置
port 6382
daemonize yes
pidfile /data/6382/redis.pid
loglevel notice
logfile "/data/6382/redis.log"
dbfilename dump.rdb
dir /data/6382
protected-mode no
```

再创建两个配置文件6381和6382

```
sed "s/6380/6381/g" redis-6380.conf > redis-6381.conf
sed "s/6380/6382/g" redis-6380.conf > redis-6382.conf
```



在跟目录创建数据库文件

```
[root@qishi666 redis_conf]# mkdir -p /data/6380
[root@qishi666 redis_conf]# mkdir -p /data/6381
[root@qishi666 redis_conf]# mkdir -p /data/6382
```



启动redis数据库

```
[root@qishi666 redis_conf]# redis-server redis-6380.conf 
[root@qishi666 redis_conf]# redis-server redis-6381.conf 
[root@qishi666 redis_conf]# redis-server redis-6382.conf

```



确保这三个redis数据库是完全独立的数据库

给两个从服务器配置文件再添加一行配置文件：

```
在6381和6382配置文件添加这一行配置，表示指定主服务器为6380
slaveof 127.0.0.1 6380
```



重启数据库

```
pkill redis
redis-server /opt/redis_conf/redis-6380.conf
redis-server /opt/redis_conf/redis-6381.conf
redis-server /opt/redis_conf/redis-6382.conf
```



查看主从数据库状态

```
redis-cli -p 6380 info
redis-cli -p 6380 info replication
```

![](H:\深圳6期资料\Linux\day07\assets\1568860565149.png)

![](H:\深圳6期资料\Linux\day07\assets\1568860664376.png)



添加数据进行测试

```
redis-cli -p 6380   #进入数据库
set name wcx        #设置值
keys *             #查看值
get name           #查看name的值
exit               #退出

```





手动进行主从复制故障切换

关闭6381的从库身份

```
redis-cli -p 6381
info replication
slaveof no one
```

将6382设为6381的从库

```
6382连接到6381：
[root@db03 ~]# redis-cli -p 6382
127.0.0.1:6382> SLAVEOF no one
127.0.0.1:6382> SLAVEOF 127.0.0.1 6381
```







# 12.redis哨兵

![](H:\深圳6期资料\Linux\day08\assets\1573695903925.png)



sentinel主要功能如下：

。不时的监控redis是否良好运行，如果节点不可达就睡对节点进行下线标识。

。如果被标识的是主节点，sentinel就会和其他的sentinel节点协商，如果其他节点为主节点不可达，就会选举一个sentinel节点来完成自动故障转义

。在master-slave进行切换后，master_redis.conf，slave_redis.conf和 sentinel.conf的内容都会发生改变，即master_redis.conf中会多出一行slaveof的配置，sentinel,conf的监控目标会随之调换。

![](H:\深圳6期资料\Linux\day08\assets\1568863832928.png)

![](H:\深圳6期资料\Linux\day08\assets\1573696691863.png)

![](H:\深圳6期资料\Linux\day08\assets\1573696893908.png)



redis配置sentinel步骤

配置三个redis数据库，一主二从

```
redis-6380.conf
redis-6381.conf
redis-6382.conf
```

启动三个redis数据库，确保主从复制正常运行

```
redis-server redis-6380.conf
redis-server redis-6381.conf
redis-server redis-6382.conf
```

```
redis-cli -p 6380 info replication
redis-cli -p 6381 info replication
redis-cli -p 6382 info replication
```



配置三个哨兵

```
cd /opt/redis_conf
vim redis-sentinel-26380.conf
vim redis-sentinel-26381.conf
vim redis-sentinel-26382.conf
```



写入一下配置文件

```
port 26380
dir /data/26380
logfile "26380.log"
sentinel monitor qishimaster 127.0.0.1 6380 2
sentinel down-after-milliseconds qishimaster 60000
sentinel parallel-syncs qishimaster 1
sentinel failover-timeout qishimaster 180000
daemonize yes
```



哨兵配置详解

```
# Sentinel节点的端口
port 26379  
dir /var/redis/data/
logfile "26379.log"

# sentinel announce-ip 127.0.0.1   # 宣告哨兵IP, 此配置只有当使用非127.0.0.1的IP配置哨兵无法成功时加上，同时redis三个服务端也需要同步修改IP

# 当前Sentinel节点监控 127.0.0.1:6379 这个主节点
# 2代表判断主节点失败至少需要2个Sentinel节点节点同意
# mymaster是主节点的别名
sentinel monitor mymaster 127.0.0.1 6379 2

# 每个Sentinel节点都要定期PING命令来判断Redis数据节点和其余Sentinel节点是否可达，如果超过30000毫秒30s且没有回复，则判定不可达
sentinel down-after-milliseconds mymaster 30000

# 当Sentinel节点集合对主节点故障判定达成一致时，Sentinel领导者节点会做故障转移操作，选出新的主节点，原来的从节点会向新的主节点发起复制操作，限制每次向新的主节点发起复制操作的从节点个数为1
sentinel parallel-syncs mymaster 1

# 故障转移超时时间为180000毫秒
sentinel failover-timeout mymaster 180000

daemonize yes
```



创建存放哨兵文件的目录

```
mkdir -p /data/{26380,26381,26382}
```



如果发现哨兵没有正常启动，必须把ip改为127.0.0.1



如果是在三个不同的机器上，只能用机器对外访问的ip，那就需要添加一个配合：

```
sentinel announce-ip 127.0.0.1
```





启动三个哨兵

```
[root@qishi666 redis_conf]# redis-sentinel redis-sentinel-26381.conf 
[root@qishi666 redis_conf]# redis-sentinel redis-sentinel-26382.conf 
[root@qishi666 redis_conf]# redis-sentinel redis-sentinel-26383.conf 
```



此时查看哨兵是否成功通信

![](H:\深圳6期资料\Linux\day08\assets\1573698024702.png)

![](H:\深圳6期资料\Linux\day08\assets\1568864859515.png)



如果出现问题，没有配置成功，没有显示前面的几条配置成功的信息，就推到重来。



验证redis高可故障切换

大致思路：

杀掉主节点的redis进行6379端口，观察从节点是否会进行新的master选举，进行切换。

重新恢复久的master节点，查看此时的redis身份



首先查看三个redis的进程状态

![](H:\深圳6期资料\Linux\day08\assets\1573698477242.png)



再把6380启动起来，查看他们的主从状态

![](H:\深圳6期资料\Linux\day08\assets\1573698729075.png)







# 13.redis集群概念



为什么需要用到集群

全量数据，量很大，一台机器没办法全部处理完成，所以需要多台机器同事处理，才能达到我们想要的效果。



redis集群槽位概念

虚拟槽分区巧妙的使用了哈希空间，使用分散度良好的哈希函数把所有的数据映射到一个固定范围的证书集合，证书定义为槽（slot）



Redis Cluster槽的范围是0-16383.

槽是集群neural数据管理和迁移的基本单位。采用大范围的槽的主要目的是为了方便数据的查分和集群的扩展。



每个节点负责一定数量的槽。

![](H:\深圳6期资料\Linux\day08\assets\1568877345505.png)





redis集群配置。

准备留个节点

```
cd /opt/jq
vim redis-7000.conf
vim redis-7001.conf
vim redis-7002.conf
vim redis-7003.conf
vim redis-7004.conf
vim redis-7005.conf
```



写入配置

```
port 7000
daemonize yes
dir "/data/jq/7000"
logfile "7000.log"
dbfilename "dump-7000.rdb"
cluster-enabled yes
cluster-config-file nodes-7000.conf
```

这留个节点配置文件都一样，仅仅是端口的不同、

```
[root@qishi666 jq]# sed "s/7000/7001/g" redis-7000.conf > redis-7001.conf
[root@qishi666 jq]# sed "s/7000/7002/g" redis-7000.conf > redis-7002.conf
[root@qishi666 jq]# sed "s/7000/7003/g" redis-7000.conf > redis-7003.conf
[root@qishi666 jq]# sed "s/7000/7004/g" redis-7000.conf > redis-7004.conf
[root@qishi666 jq]# sed "s/7000/7005/g" redis-7000.conf > redis-7005.conf
```



创建这留个节点的文件目录

```
mkdir -p /data/jq/{7000,7001,7002,7003,7004,7005}
```



启动这六个节点

```
cd /opt/jq
redis-server redis-7000.conf
redis-server redis-7001.conf
redis-server redis-7002.conf
redis-server redis-7003.conf
redis-server redis-7004.conf
redis-server redis-7005.conf
```



随便进入一个redis交互模式，写入数据，发现无法写入数据

报错 ，没有分配哈希槽。

![](H:\深圳6期资料\Linux\day08\assets\1568878141439.png)



准备ruby环境，安装ruby并执行redis-trib.rb脚本

分配redis集群状态，以及槽位分配，互联网企业，豆瓣公司开源的一个公具。

下载，编译，安装Ruby

下载

```
# 下载ruby
wget https://cache.ruby-lang.org/pub/ruby/2.3/ruby-2.3.1.tar.gz

# 安装ruby
tar -xvf ruby-2.3.1.tar.gz
cd ruby-2.3.1/
./configure --prefix=/opt/ruby/
make && make install
```



配置Ruby环境

配置ruby环境变量

```
vim /etc/profile
```



在PATH=后面添加ruby的环境变量路径

```
PATH=/opt/ruby/bin:/opt/python36/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin
```



安装rubygem redis

```
wget http://rubygems.org/downloads/redis-3.3.0.gem
```



使用gem安装redis-3.3.o.gem公具

```
gem install -l redis-3.3.0.gem
```



安装redis-trib.rb命令

```
cp /opt/redis/src/redis-trib.rb /usr/local/bin/
```





安装ruby gem 包管理公具

 

 下载gem包

```
wget http://rubygems.org/downloads/redis-3.3.0.gem
```



安装

```
gem install -l redis-3.3.0.gem
```



一键开启redis-cluster集群



一条命令开启集群

```
redis-cli --cluster create --cluster-replicas 1 127.0.0.1:7000 127.0.0.1:7001 127.0.0.1:7002 127.0.0.1:7003 127.0.0.1:7004 127.0.0.1:7005

# 每个主节点，有一个从节点，代表--replicas 1
# 集群自动分配主从关系  7000、7001、7002为主 7003、7004、7005为从
```





查看集群状态

![](H:\深圳6期资料\Linux\day08\assets\1568879254315.png)

![](H:\深圳6期资料\Linux\day08\assets\1573702919190.png)



进入集群状态

```
redis-cli -p 7000 -c
```







# 14.docker入门

 