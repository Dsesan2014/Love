# FastDFS分布式文件系统

## 4. 使用nginx代理访问Fastdfs的图片

接下来我们已经完成了django上传文件到fastdfs了，接下来我们需要在浏览器中显示上传的图片，所以接下来我们使用镜像来完成这个功能.这个镜像本质就是一个nginx.

```
1. 把镜像加载到docker中
sudo docker load -i ~/Desktop/fastdfs_nginx_0.0.1.tar.gz
2. 创建容器
sudo docker run -itd --network=host --name fdfs_nginx -v /home/moluo/store_path/:/home/store_path fastdfs_nginx:0.0.1
3. 进入镜像里面，执行以下命令，启动nginx
/usr/local/nginx/sbin/nginx
```



# 文章模块

创建子引用

```bash\
cd renranapi/apps
python ../../manage.py startapp article
```

注册子应用

```python
INSTALLED_APPS = [
	# ....
    'article',

]
```

## 模型代码

article./models.py,代码:

```python
from django.db import models
from renranapi.utils.models import BaseModel
from users.models import User
# create your models here.
class ArticleCollection(BaseModel):
    """文集模型"""
    name = models.CharField(max_length=200, verbose_name="文章标题")
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, verbose_name="用户")
    class Meta:
        db_table = "rr_article_collection"
        verbose_name = "文集"
        verbose_name_plural = verbose_name

class Special(BaseModel):
    """专题模型"""
    name = models.CharField(max_length=200, verbose_name="文章标题")
    image = models.ImageField(null=True, blank=True, verbose_name="封面图片")
    notice = models.TextField(null=True, blank=True, verbose_name="专题公告")
    article_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="文章总数")
    follow_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="关注量量")
    collect_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="收藏量")
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, verbose_name="创建人")
    class Meta:
        db_table = "rr_special"
        verbose_name = "专题"
        verbose_name_plural = verbose_name

class Article(BaseModel):
    """文章模型"""
    title = models.CharField(max_length=200, verbose_name="文章标题")
    content = models.TextField(null=True, blank=True, verbose_name="文章内容")
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, verbose_name="用户")
    collection = models.ForeignKey(ArticleCollection, on_delete=models.CASCADE, verbose_name="文集")
    pub_date = models.DateTimeField(null=True, default=None, verbose_name="发布时间")
    access_pwd = models.CharField(max_length=15,null=True, blank=True, verbose_name="访问密码")
    read_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="阅读量")
    like_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="点赞量")
    collect_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="收藏量")
    comment_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="评论量")
    reward_count = models.IntegerField(default=0, null=True, blank=True, verbose_name="赞赏量")
    is_public = models.BooleanField(default=False, verbose_name="是否公开")
    class Meta:
        db_table = "rr_article"
        verbose_name = "文章"
        verbose_name_plural = verbose_name

class SpecialArticle(BaseModel):
    """文章和专题的绑定关系"""
    article = models.ForeignKey(Article, on_delete=models.CASCADE, verbose_name="文章")
    special = models.ForeignKey(Special, on_delete=models.CASCADE, verbose_name="专题")

    class Meta:
        db_table = "rr_special_article"
        verbose_name = "专题的文章"
        verbose_name_plural = verbose_name
 

class SpecialManager(BaseModel):
    """专题管理员"""
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, verbose_name="管理员")
    special = models.ForeignKey(Special, on_delete=models.CASCADE, verbose_name="专题")

    class Meta:
        db_table = "rr_special_manager"
        verbose_name = "专题的管理员"
        verbose_name_plural = verbose_name

class SpecialFocus(BaseModel):
    """专题关注"""
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, verbose_name="管理员")
    special = models.ForeignKey(Special, on_delete=models.CASCADE, verbose_name="专题")

    class Meta:
        db_table = "rr_special_focus"
        verbose_name = "专题的关注"
        verbose_name_plural = verbose_name

class SpecialCollection(BaseModel):
    """专题收藏"""
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, verbose_name="管理员")
    special = models.ForeignKey(Special, on_delete=models.CASCADE, verbose_name="专题")

    class Meta:
        db_table = "rr_special_collection"
        verbose_name = "专题收藏"
        verbose_name_plural = verbose_name


class ArticleImage(BaseModel):
    """文章图片"""
    group = models.CharField(max_length=15,null=True, blank=True, verbose_name="组名")
    link = models.CharField(max_length=300, null=True, blank=True, verbose_name="图片地址")

    class Meta:
        db_table = "rr_article_image"
        verbose_name = "文章图片"
        verbose_name_plural = verbose_name
```

数据迁移

```
python manage.py makemigrations
python manage.py migrate
```



## 相关依赖

### 在vue中引入集成markdown富文本编辑器

这里我们使用 mavonEditor，链接：https://github.com/hinesboy/mavonEditor

#### 安装

```bash
cd renran_pc
npm install mavon-editor --save
```

在main.js中注册编辑器组件

```javascript
    import mavonEditor from 'mavon-editor'
    import 'mavon-editor/dist/css/index.css'
	// 注册mavon-editor组件
    Vue.use(mavonEditor);
    new Vue({
        'el': '#main'
    })
```



## 写文章页面

创建Write.vue组件，提供给用户编写文章

```vue
<template>
  <div class="write">
    <div class="_2v5v5">
      <div class="_3zibT">
        <a href="">回首页</a>
      </div>
      <div class="_1iZMb">
        <div class="_33Zlg"><i class="fa fa-plus"></i><span>新建文集</span></div>
      </div>
      <ul class="_3MbJ4 _3t059">
        <li class="_3DM7w" title="日记本"><span>日记本</span></li>
        <li class="_3DM7w" title="随笔"><span>随笔</span></li>
      </ul>
    </div>
    <div id="editor">
      <mavon-editor
        style="height: 100%"
        v-model="editorContent"
        :ishljs="true"
        ref=md
        @imgAdd="imgAdd"
        @imgDel="imgDel"
      ></mavon-editor>
    </div>
      </div>
</template>
<script>
  import { mavonEditor } from 'mavon-editor'
  import 'mavon-editor/dist/css/index.css'
    export default {
        name: "Write",
        data(){
            return {
                editorContent:"",
                img_file:[],
            }
        },
        watch:{
            editorContent(){
                console.log(this.editorContent)
            }
        },
        components: {
          mavonEditor
        },
        methods:{
          // 绑定@imgAdd event
          imgAdd(pos, $file){
  
          },
          imgDel(pos) {
             
          }
        }
    }
</script>

<style scoped>
._2v5v5 {
    position: relative;
    height: 100%;
    overflow-y: auto;
    background-color: #404040;
    color: #f2f2f2;
    z-index: 100;
    box-sizing: border-box;
    width: 16.66666667%;
    display: block;
    flex: 0 0 auto;
    float: left;
    padding-right: 0;
    padding-left: 0;
    min-height: 1px;
}
._3zibT {
    padding: 30px 18px 5px;
    text-align: center;
    box-sizing: border-box;
}
._3zibT a {
    display: block;
    font-size: 15px;
    padding: 9px 0;
    color: #ec7259;
    border: 1px solid rgba(236,114,89,.8);
    border-radius: 20px;
    -webkit-transition: border-color .2s ease-in;
    -o-transition: border-color .2s ease-in;
    transition: border-color .2s ease-in;
}
._1iZMb {
    padding: 0 15px;
    margin-top: 20px;
    margin-bottom: 10px;
    box-sizing: border-box;
}
._1iZMb ._33Zlg {
    cursor: pointer;
    color: #f2f2f2;
    -webkit-transition: color .2s cubic-bezier(.645,.045,.355,1);
    -o-transition: color .2s cubic-bezier(.645,.045,.355,1);
    transition: color .2s cubic-bezier(.645,.045,.355,1);
    box-sizing: border-box;
}
._1iZMb ._33Zlg .fa+span {
    margin-left: 4px;
}
._3t059 {
    position: relative;
    z-index: 0;
    background-color: #8c8c8c;
}
._3MbJ4 {
    margin-bottom: 0;
}
._3DM7w {
    position: relative;
    line-height: 40px;
    list-style: none;
    font-size: 15px;
    color: #f2f2f2;
    background-color: #404040;
    padding: 0 15px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
._3DM7w span {
    display: block;
    margin-right: 20px;
    overflow: hidden;
    -o-text-overflow: ellipsis;
    text-overflow: ellipsis;
    white-space: nowrap;
}
  #editor {
    margin: auto;
    width: 80%;
    height: 580px;
  }
</style>

```

路由代码：

```javascript
// 。。。
import Write from "@/components/Write"


export default new Router({
  mode: "history",
  routes: [
     // ....
      {
       name:"Write",
       path:"/write",
       component: Write,
     },
  ]
})

```

在 Header.vue提供跳转链接

```vue
<router-link class="btn write-btn" target="_blank" to="/writer"><img class="icon-write" src="/static/image/write.svg">写文章</router-link>
```

