#　短信有效期为300s
SMS_CODE_EXPIRE = 5 * 60
#　短信发送冷却时间
SMS_CODE_INTERVAL = 60
# 找回密码的邮件有效期[实际上是access_token的有效期]
DATA_SIGNATURE_EXPIRE = 2 * 60 * 60