export default {
  Host:"http://api.renran.cn:8000",
  TC_captcha:{
    app_id: "2086888489",
  }
}
